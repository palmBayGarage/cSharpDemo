﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Glover_CourseProject_Part1
{
    public partial class Form1 : Form
    {
        string newLine = "\r\n";
        Control ctrl;
        public Form1()
        {
            InitializeComponent();
        }
        #region SongInList Method
        private bool SongInList(string songTitle)
        {
            bool boolFlag = false;
            foreach (var item in songList.Items)
            {
                string currentSong = item as string;
                if (songTitle == currentSong)
                    {
                    boolFlag =true;
                    }
            }
            return boolFlag;
        }
        #endregion
        #region ValidInput() Method
        private bool ValidInput()
        {
            StringBuilder sb = new StringBuilder(string.Empty);
            bool boolFlag = true;
            string stringErrorMessage = "Please correct the following errors:";

            if (string.IsNullOrEmpty(titleText.Text) || string.IsNullOrEmpty(artistText.Text)
                    || string.IsNullOrEmpty(genreCombo.Text) || string.IsNullOrEmpty(yearText.Text)
                    || string.IsNullOrEmpty(urlText.Text))
            {
                stringErrorMessage += string.IsNullOrEmpty(titleText.Text) ? "\n ~ Title cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(artistText.Text) ? "\n ~ Artist cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(genreCombo.Text) ? "\n ~ Genre cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(yearText.Text) ? "\n ~ Year cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(urlText.Text) ? "\n ~ URL cannot be blank" : string.Empty;
                boolFlag = false;
            }

            if (!boolFlag)
            {
                MessageBox.Show(stringErrorMessage, "Missing Input", MessageBoxButtons.OK);
            }
            return boolFlag;
        }
        #endregion
        #region Add Song Button Event
        private void addSongButton_Click(object sender, EventArgs e)
        {
         StringBuilder sb = new StringBuilder(String.Empty);
         string newLine = "\r\n";

            if (ValidInput())
            {
                //No blank Fields, build output text
                sb.Append(newLine);
                sb.Append(titleText.Text);
                sb.Append(newLine);
                sb.Append(artistText.Text);
                sb.Append(newLine);
                sb.Append(genreCombo.Text);
                sb.Append(newLine);
                sb.Append(yearText.Text);
                sb.Append(newLine);
                sb.Append(urlText.Text);
                sb.Append(newLine);
                sb.Append(newLine);

                //Output text to 'Details' textbox
                outputText.Text = sb.ToString();
                //Output Song Title to 'Songs' listbox
                songList.Items.Add(titleText.Text);
                //Clear Text Fields for additonal entry
                titleText.Text = "";
                artistText.Text = "";
                genreCombo.Text = "";
                yearText.Text = "";
                urlText.Text = "";

            }
        }
        #endregion
        #region All Song Button Event 
        private void allSongsButton_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder(string.Empty);
            
            //Build the list of songs to ouput into the outputText textbox 'Details'
            foreach (var item in songList.Items)
            {
                sb.Append(item.ToString());
                sb.Append(newLine);
            }

            //Displays list of songs built in previous lines to outputText textbox 'Details'
            outputText.Text = sb.ToString();

        }
        #endregion
        #region Clicking X

        //If something is typed into the Title Textbox titleX label becomes visible
        private void titleText_TextChanged(object sender, EventArgs e)
        {
            if (titleText.Text != "")
            {
                titleX.Visible = true;
            }
            else
            {
                titleX.Visible = false;
            }
        }
        //If the user clicks the 'x' the title field clears
        private void titleX_Click(object sender, EventArgs e)
        {
            titleText.Text = ""; 
        }
        //If something is typed into the artist textbox the artistX label becomes visible
        private void artistText_TextChanged(object sender, EventArgs e)
        {
            if(artistText.Text != "")
            { artistX.Visible = true;}
            else { artistX.Visible = false;}
        }
        //If the user clicks the x, the artist textbox clears
        private void artistX_Click(object sender, EventArgs e)
        {
            artistText.Text = "";
        }
  
        //If something is typed into the year textbox, the yearX label becomes visible
        private void yearText_TextChanged(object sender, EventArgs e)
        {
            if(yearText.Text != "")
            { yearX.Visible = true;}
            else { yearX.Visible = false;}
        }
        //If the user clicks the x, the year textbox clears
        private void yearX_Click(object sender, EventArgs e)
        {
            yearText.Text = "";
        }
        //If something is typed into the URL textbox, the urlX label becomes visible
        private void urlText_TextChanged(object sender, EventArgs e)
        {
            if(urlText.Text != "")
            { urlX.Visible = true; }
            else { urlX.Visible = false; }
        }
        //If the user clicks the x, the url textbox clears
        private void urlX_Click(object sender, EventArgs e)
        {
            urlText.Text = "";
        }
        #endregion
        #region Clear Song Button Event
        private void clearSongButton_Click(object sender, EventArgs e)
        {
            titleText.Text = "";
            artistText.Text = "";
            genreCombo.Text = "";
            yearText.Text = "";
            urlText.Text = "";
        }
        #endregion
        #region Find Song Button Event
        private void findSongButton_Click(object sender, EventArgs e)
        {
            if(SongInList(titleText.Text))
            {
                MessageBox.Show(string.Format("{0} found!",titleText.Text));
            }
            else
            {
                MessageBox.Show(string.Format("{0} not found. Please search for another song, or check spelling and"
                    + " punctuation.",titleText.Text));
            }
        }
        #endregion
        #region Enter acts as Tab
        private void titleText_KeyDown(object sender, KeyEventArgs e)
        {
            ctrl = (Control)sender;
            if (ctrl is TextBox)
            {
                if(e.KeyCode == Keys.Enter || e.KeyCode ==Keys.Down)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
                else
                {
                    return;
                }
            }
            else
            {
                if(e.KeyCode == Keys.Enter)
                {
                    this.SelectNextControl(ctrl, true, true, true, true );
                }
                else if (e.KeyCode == Keys.Up && e.Control)
                {
                    this.SelectNextControl(ctrl, false, true, true, true );
                }
            }

        }

        private void artistText_KeyDown(object sender, KeyEventArgs e)
        {
            ctrl = (Control)sender;
            if (ctrl is TextBox)
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Down)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (e.KeyCode == Keys.Enter)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up && e.Control)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
            }
        }



        private void yearText_KeyDown(object sender, KeyEventArgs e)
        {
            ctrl = (Control)sender;
            if (ctrl is TextBox)
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Down)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (e.KeyCode == Keys.Enter)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up && e.Control)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
            }
        }

        private void urlText_KeyDown(object sender, KeyEventArgs e)
        {
            ctrl = (Control)sender;
            if (ctrl is TextBox)
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Down)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (e.KeyCode == Keys.Enter)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up && e.Control)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
            }
        }

        private void songList_KeyDown(object sender, KeyEventArgs e)
        {
            ctrl = (Control)sender;
            if (ctrl is TextBox)
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Down)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (e.KeyCode == Keys.Enter)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up && e.Control)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
            }
        }

        private void outputText_KeyDown(object sender, KeyEventArgs e)
        {
            ctrl = (Control)sender;
            if (ctrl is TextBox)
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Down)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (e.KeyCode == Keys.Enter)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up && e.Control)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
            }
        }
        private void genreCombo_KeyDown(object sender, KeyEventArgs e)
        {
            ctrl = (Control)sender;
            if (ctrl is TextBox)
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Down)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (e.KeyCode == Keys.Enter)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                }
                else if (e.KeyCode == Keys.Up && e.Control)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                }
            }
        }
        #endregion
    }
}
