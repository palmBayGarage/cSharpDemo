﻿namespace Glover_CourseProject_Part1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.titleText = new System.Windows.Forms.TextBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.artistLabel = new System.Windows.Forms.Label();
            this.artistText = new System.Windows.Forms.TextBox();
            this.genreLabel = new System.Windows.Forms.Label();
            this.yearLabel = new System.Windows.Forms.Label();
            this.yearText = new System.Windows.Forms.TextBox();
            this.urlLabel = new System.Windows.Forms.Label();
            this.urlText = new System.Windows.Forms.TextBox();
            this.outputText = new System.Windows.Forms.TextBox();
            this.addSongButton = new System.Windows.Forms.Button();
            this.songList = new System.Windows.Forms.ListBox();
            this.songText = new System.Windows.Forms.Label();
            this.detailText = new System.Windows.Forms.Label();
            this.allSongsButton = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.titleX = new System.Windows.Forms.Label();
            this.artistX = new System.Windows.Forms.Label();
            this.yearX = new System.Windows.Forms.Label();
            this.urlX = new System.Windows.Forms.Label();
            this.clearSongButton = new System.Windows.Forms.Button();
            this.findSongButton = new System.Windows.Forms.Button();
            this.genreCombo = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // titleText
            // 
            this.titleText.Location = new System.Drawing.Point(97, 69);
            this.titleText.Name = "titleText";
            this.titleText.Size = new System.Drawing.Size(275, 22);
            this.titleText.TabIndex = 0;
            this.toolTip1.SetToolTip(this.titleText, "Enter Title of Song");
            this.titleText.TextChanged += new System.EventHandler(this.titleText_TextChanged);
            this.titleText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.titleText_KeyDown);
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(29, 75);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(41, 20);
            this.titleLabel.TabIndex = 1;
            this.titleLabel.Text = "Title";
            // 
            // artistLabel
            // 
            this.artistLabel.AutoSize = true;
            this.artistLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.artistLabel.Location = new System.Drawing.Point(29, 122);
            this.artistLabel.Name = "artistLabel";
            this.artistLabel.Size = new System.Drawing.Size(49, 20);
            this.artistLabel.TabIndex = 3;
            this.artistLabel.Text = "Artist";
            // 
            // artistText
            // 
            this.artistText.Location = new System.Drawing.Point(97, 116);
            this.artistText.Name = "artistText";
            this.artistText.Size = new System.Drawing.Size(275, 22);
            this.artistText.TabIndex = 1;
            this.toolTip1.SetToolTip(this.artistText, "Enter Artist of Song");
            this.artistText.TextChanged += new System.EventHandler(this.artistText_TextChanged);
            this.artistText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.artistText_KeyDown);
            // 
            // genreLabel
            // 
            this.genreLabel.AutoSize = true;
            this.genreLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genreLabel.Location = new System.Drawing.Point(29, 168);
            this.genreLabel.Name = "genreLabel";
            this.genreLabel.Size = new System.Drawing.Size(55, 20);
            this.genreLabel.TabIndex = 5;
            this.genreLabel.Text = "Genre";
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearLabel.Location = new System.Drawing.Point(29, 217);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(43, 20);
            this.yearLabel.TabIndex = 7;
            this.yearLabel.Text = "Year";
            // 
            // yearText
            // 
            this.yearText.Location = new System.Drawing.Point(97, 211);
            this.yearText.Name = "yearText";
            this.yearText.Size = new System.Drawing.Size(275, 22);
            this.yearText.TabIndex = 3;
            this.toolTip1.SetToolTip(this.yearText, "Enter Year Song was Produced");
            this.yearText.TextChanged += new System.EventHandler(this.yearText_TextChanged);
            this.yearText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.yearText_KeyDown);
            // 
            // urlLabel
            // 
            this.urlLabel.AutoSize = true;
            this.urlLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.urlLabel.Location = new System.Drawing.Point(29, 260);
            this.urlLabel.Name = "urlLabel";
            this.urlLabel.Size = new System.Drawing.Size(43, 20);
            this.urlLabel.TabIndex = 9;
            this.urlLabel.Text = "URL";
            // 
            // urlText
            // 
            this.urlText.Location = new System.Drawing.Point(97, 254);
            this.urlText.Name = "urlText";
            this.urlText.Size = new System.Drawing.Size(275, 22);
            this.urlText.TabIndex = 4;
            this.toolTip1.SetToolTip(this.urlText, "Enter URL to find Song");
            this.urlText.TextChanged += new System.EventHandler(this.urlText_TextChanged);
            this.urlText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.urlText_KeyDown);
            // 
            // outputText
            // 
            this.outputText.Location = new System.Drawing.Point(417, 246);
            this.outputText.Multiline = true;
            this.outputText.Name = "outputText";
            this.outputText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.outputText.Size = new System.Drawing.Size(344, 143);
            this.outputText.TabIndex = 10;
            this.toolTip1.SetToolTip(this.outputText, "Detailed information about song");
            this.outputText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.outputText_KeyDown);
            // 
            // addSongButton
            // 
            this.addSongButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addSongButton.Location = new System.Drawing.Point(97, 314);
            this.addSongButton.Name = "addSongButton";
            this.addSongButton.Size = new System.Drawing.Size(126, 38);
            this.addSongButton.TabIndex = 5;
            this.addSongButton.Text = "Add Song";
            this.toolTip1.SetToolTip(this.addSongButton, "Add a Song to the Song List");
            this.addSongButton.UseVisualStyleBackColor = true;
            this.addSongButton.Click += new System.EventHandler(this.addSongButton_Click);
            // 
            // songList
            // 
            this.songList.FormattingEnabled = true;
            this.songList.HorizontalScrollbar = true;
            this.songList.ItemHeight = 16;
            this.songList.Location = new System.Drawing.Point(417, 43);
            this.songList.Name = "songList";
            this.songList.ScrollAlwaysVisible = true;
            this.songList.Size = new System.Drawing.Size(344, 164);
            this.songList.TabIndex = 9;
            this.toolTip1.SetToolTip(this.songList, "List of Songs");
            this.songList.KeyDown += new System.Windows.Forms.KeyEventHandler(this.songList_KeyDown);
            // 
            // songText
            // 
            this.songText.AutoSize = true;
            this.songText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.songText.Location = new System.Drawing.Point(414, 20);
            this.songText.Name = "songText";
            this.songText.Size = new System.Drawing.Size(80, 20);
            this.songText.TabIndex = 13;
            this.songText.Text = "Song List";
            // 
            // detailText
            // 
            this.detailText.AutoSize = true;
            this.detailText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detailText.Location = new System.Drawing.Point(414, 223);
            this.detailText.Name = "detailText";
            this.detailText.Size = new System.Drawing.Size(62, 20);
            this.detailText.TabIndex = 14;
            this.detailText.Text = "Details";
            // 
            // allSongsButton
            // 
            this.allSongsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allSongsButton.Location = new System.Drawing.Point(233, 314);
            this.allSongsButton.Name = "allSongsButton";
            this.allSongsButton.Size = new System.Drawing.Size(139, 38);
            this.allSongsButton.TabIndex = 6;
            this.allSongsButton.Text = "Show All Songs";
            this.toolTip1.SetToolTip(this.allSongsButton, "Click to show all songs in Details");
            this.allSongsButton.UseVisualStyleBackColor = true;
            this.allSongsButton.Click += new System.EventHandler(this.allSongsButton_Click);
            // 
            // titleX
            // 
            this.titleX.AutoSize = true;
            this.titleX.Location = new System.Drawing.Point(359, 72);
            this.titleX.Name = "titleX";
            this.titleX.Size = new System.Drawing.Size(13, 16);
            this.titleX.TabIndex = 15;
            this.titleX.Text = "x";
            this.titleX.Visible = false;
            this.titleX.Click += new System.EventHandler(this.titleX_Click);
            // 
            // artistX
            // 
            this.artistX.AutoSize = true;
            this.artistX.Location = new System.Drawing.Point(359, 119);
            this.artistX.Name = "artistX";
            this.artistX.Size = new System.Drawing.Size(13, 16);
            this.artistX.TabIndex = 16;
            this.artistX.Text = "x";
            this.artistX.Visible = false;
            this.artistX.Click += new System.EventHandler(this.artistX_Click);
            // 
            // yearX
            // 
            this.yearX.AutoSize = true;
            this.yearX.Location = new System.Drawing.Point(359, 214);
            this.yearX.Name = "yearX";
            this.yearX.Size = new System.Drawing.Size(13, 16);
            this.yearX.TabIndex = 18;
            this.yearX.Text = "x";
            this.yearX.Visible = false;
            this.yearX.Click += new System.EventHandler(this.yearX_Click);
            // 
            // urlX
            // 
            this.urlX.AutoSize = true;
            this.urlX.Location = new System.Drawing.Point(359, 257);
            this.urlX.Name = "urlX";
            this.urlX.Size = new System.Drawing.Size(13, 16);
            this.urlX.TabIndex = 19;
            this.urlX.Text = "x";
            this.urlX.Visible = false;
            this.urlX.Click += new System.EventHandler(this.urlX_Click);
            // 
            // clearSongButton
            // 
            this.clearSongButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearSongButton.Location = new System.Drawing.Point(97, 366);
            this.clearSongButton.Name = "clearSongButton";
            this.clearSongButton.Size = new System.Drawing.Size(126, 36);
            this.clearSongButton.TabIndex = 7;
            this.clearSongButton.Text = "Clear Song";
            this.clearSongButton.UseVisualStyleBackColor = true;
            this.clearSongButton.Click += new System.EventHandler(this.clearSongButton_Click);
            // 
            // findSongButton
            // 
            this.findSongButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.findSongButton.Location = new System.Drawing.Point(233, 366);
            this.findSongButton.Name = "findSongButton";
            this.findSongButton.Size = new System.Drawing.Size(139, 36);
            this.findSongButton.TabIndex = 8;
            this.findSongButton.Text = "Find Song";
            this.findSongButton.UseVisualStyleBackColor = true;
            this.findSongButton.Click += new System.EventHandler(this.findSongButton_Click);
            // 
            // genreCombo
            // 
            this.genreCombo.FormattingEnabled = true;
            this.genreCombo.Items.AddRange(new object[] {
            "--Select a Genre--",
            "Alternative",
            "Art Punk",
            "Alternative Rock",
            "Britpunk",
            "College Rock",
            "Crossover Thrash",
            "Crust Punk (thx Haug)",
            "Emotional Hardcore (emo / emocore)",
            "Experimental Rock",
            "Folk Punk",
            "Goth / Gothic Rock",
            "Grunge",
            "Hardcore Punk",
            "Hard Rock",
            "Indie Rock",
            "Lo-fi",
            "Musique Concrète",
            "New Wave",
            "Progressive Rock",
            "Punk",
            "Shoegaze",
            "Steampunk",
            "Anime",
            "Blues",
            "Acoustic Blues",
            "African Blues",
            "Blues Rock",
            "Blues Shouter",
            "British Blues",
            "Canadian Blues",
            "Chicago Blues",
            "Classic Blues",
            "Classic Female Blues",
            "Contemporary Blues",
            "Contemporary R&B",
            "Country Blues",
            "Dark Blues",
            "Delta Blues",
            "Detroit Blues",
            "Doom Blues",
            "Electric Blues",
            "Folk Blues",
            "Gospel Blues",
            "Harmonica Blues",
            "Hill Country Blues",
            "Hokum Blues",
            "Jazz Blues",
            "Jump Blues",
            "Kansas City Blues",
            "Louisiana Blues",
            "Memphis Blues",
            "Modern Blues",
            "New Orlean Blues",
            "NY Blues",
            "Piano Blues",
            "Piedmont Blues",
            "Punk Blues",
            "Ragtime Blues",
            "Rhythm Blues",
            "Soul Blues",
            "St. Louis Blues",
            "Soul Blues",
            "Swamp Blues",
            "Texas Blues",
            "Urban Blues",
            "Vandeville",
            "West Coast Blues",
            "Zydeco (also under ‘World’ genre)",
            "Children’s Music",
            "Lullabies",
            "Sing-Along",
            "Stories",
            "Classical",
            "Avant-Garde",
            "Ballet",
            "Baroque",
            "Cantata",
            "Chamber Music",
            "String Quartet",
            "Chant",
            "Choral",
            "Classical Crossover",
            "Concerto",
            "Concerto Grosso",
            "Contemporary Classical",
            "Early Music",
            "Expressionist",
            "High Classical",
            "Impressionist",
            "Mass Requiem",
            "Medieval",
            "Minimalism",
            "Modern Composition",
            "Modern Classical",
            "Opera",
            "Oratorio",
            "Orchestral",
            "Organum",
            "Renaissance",
            "Romantic (early period)",
            "Romantic (later period)",
            "Sonata",
            "Symphonic",
            "Symphony",
            "Twelve-tone",
            "Wedding Music",
            "Comedy",
            "Novelty",
            "Parody Music (Weird Al!)",
            "Stand-up Comedy",
            "Vaudeville",
            "Find some value? Use the list for a project? Consider a small donation!",
            "Buy me a Cuppa",
            "Commercial",
            "Jingles",
            "TV Themes",
            "Country",
            "Alternative Country",
            "Americana",
            "Australian Country",
            "Bakersfield Sound",
            "Bluegrass",
            "Progressive Bluegrass",
            "Reactionary Bluegrass",
            "Blues Country",
            "Cajun Fiddle Tunes",
            "Christian Country",
            "Classic Country",
            "Close Harmony",
            "Contemporary Bluegrass",
            "Contemporary Country",
            "Country Gospel",
            "Country Pop",
            "Country Rap",
            "Country Rock",
            "Country Soul",
            "Cowboy / Western",
            "Cowpunk",
            "Dansband",
            "Honky Tonk",
            "Franco-Country",
            "Gulf and Western",
            "Hellbilly Music",
            "Honky Tonk",
            "Instrumental Country",
            "Lubbock Sound",
            "Nashville Sound",
            "Neotraditional Country",
            "Outlaw Country",
            "Progressive",
            "Psychobilly / Punkabilly",
            "Red Dirt",
            "Sertanejo",
            "Texas County",
            "Traditional Bluegrass",
            "Traditional Country",
            "Truck-Driving Country",
            "Urban Cowboy",
            "Western Swing",
            "Zydeco",
            "Dance (EDM – Electronic Dance Music – see Electronic below)",
            "Club / Club Dance",
            "Breakcore",
            "Breakbeat / Breakstep",
            "4-Beat",
            "Acid Breaks",
            "Baltimore Club",
            "Big Beat",
            "Breakbeat Hardcore",
            "Broken Beat",
            "Florida Breaks",
            "Nu Skool Breaks",
            "Brostep",
            "Chillstep",
            "Deep House",
            "Dubstep",
            "Electro House",
            "Electroswing",
            "Exercise",
            "Future Garage",
            "Garage",
            "Glitch Hop",
            "Glitch Pop",
            "Grime",
            "Hardcore",
            "Bouncy House",
            "Bouncy Techno",
            "Breakcore",
            "Digital Hardcore",
            "Doomcore",
            "Dubstyle",
            "Gabber",
            "Happy Hardcore",
            "Hardstyle",
            "Jumpstyle",
            "Makina",
            "Speedcore",
            "Terrorcore",
            "Uk Hardcore",
            "Hard Dance",
            "Hi-NRG / Eurodance",
            "Horrorcore (thx Matt)",
            "House",
            "Acid House",
            "Chicago House",
            "Deep House",
            "Diva House",
            "Dutch House",
            "Electro House",
            "Freestyle House",
            "French House",
            "Funky House",
            "Ghetto House",
            "Hardbag",
            "Hip House",
            "Italo House",
            "Latin House",
            "Minimal House",
            "Progressive House",
            "Rave Music",
            "Swing House",
            "Tech House",
            "Tribal House",
            "Tropical House",
            "UK Hard House",
            "US Garage",
            "Vocal House",
            "Jackin House",
            "Jungle / Drum’n’bass",
            "Liquid Dub",
            "Regstep",
            "Speedcore",
            "Techno",
            "Acid Techno",
            "Detroit Techno",
            "Free Tekno",
            "Ghettotech",
            "Minimal",
            "Nortec",
            "Schranz",
            "Techno-Dnb",
            "Technopop",
            "Tecno Brega",
            "Toytown Techno",
            "Trance",
            "Acid Trance",
            "Acid-House",
            "Classic Trance",
            "Dark Psy",
            "Deep House",
            "Dream Trance",
            "Goa Trance",
            "Dark Psytrance",
            "Full on",
            "Psybreaks",
            "Psyprog",
            "Suomisaundi",
            "Hard Trance",
            "Prog. Trance",
            "Psy-Trance",
            "Minimal Techno",
            "Tech House",
            "Tech Trance",
            "Uplifting Trance",
            "Orchestral Uplifting",
            "Vocal Trance",
            "Trap",
            "Disney",
            "Easy Listening",
            "Background",
            "Bop",
            "Elevator",
            "Furniture",
            "Lounge",
            "Middle of the Road",
            "Swing",
            "Electronic",
            "2-Step (thx Ran’dom Haug)",
            "8bit – aka 8-bit, Bitpop and Chiptune (see below)",
            "Ambient",
            "Ambient Dub",
            "Ambient House",
            "Ambient Techno",
            "Dark Ambient",
            "Drone Music",
            "Illbient",
            "Isolationism",
            "Lowercase",
            "Asian Underground",
            "Bassline",
            "Chillwave",
            "Chiptune",
            "Bitpop",
            "Game Boy",
            "Nintendocore",
            "Video Game Music",
            "Yorkshire Bleeps and Bass",
            "Crunk",
            "Downtempo",
            "Acid Jazz",
            "Balearic Beat",
            "Chill Out",
            "Dub Music",
            "Dubtronica",
            "Ethnic Electronica",
            "Moombahton",
            "Nu Jazz",
            "Trip Hop",
            "Drum & Bass",
            "Darkcore",
            "Darkstep",
            "Drumfunk",
            "Drumstep",
            "Hardstep",
            "Intelligent Drum and Bass",
            "Jump-Up",
            "Liquid Funk",
            "Neurofunk",
            "Oldschool Jungle:",
            "Darkside Jungle",
            "Ragga Jungle",
            "Raggacore",
            "Sambass",
            "Techstep",
            "Electro",
            "Crunk",
            "Electro Backbeat",
            "Electro-Grime",
            "Electropop",
            "Electro-swing",
            "Electroacoustic",
            "Acousmatic Music",
            "Computer Music",
            "Electroacoustic Improvisation",
            "Field Recording",
            "Live Coding",
            "Live Electronics",
            "Soundscape Composition",
            "Tape Music",
            "Electronica",
            "Berlin School",
            "Chillwave",
            "Electronic Art Music",
            "Electronic Dance Music",
            "Folktronica",
            "Freestyle Music",
            "Glitch",
            "Idm",
            "Laptronica",
            "Skweee",
            "Sound Art",
            "Synthcore",
            "Electronic Rock",
            "Alternative Dance",
            "Baggy",
            "Madchester",
            "Dance-Punk",
            "Dance-Rock",
            "Dark Wave",
            "Electroclash",
            "Electronicore",
            "Electropunk",
            "Ethereal Wave",
            "Indietronica",
            "New Rave",
            "Space Rock",
            "Synthpop",
            "Synthpunk",
            "Eurodance",
            "Bubblegum Dance",
            "Italo Dance",
            "Turbofolk",
            "Hardstyle",
            "Hi-Nrg",
            "Eurobeat",
            "Hard Nrg",
            "New Beat",
            "IDM/Experimental",
            "Industrial",
            "Trip Hop",
            "Vaporwave",
            "Hyponagogic",
            "Vektroid",
            "Mallsoft",
            "Vaportrap",
            "Vaporhop",
            "Protovapor",
            "UK Garage",
            "2-Step",
            "4×4",
            "Bassline",
            "Grime",
            "Speed Garage",
            "Enka",
            "French Pop",
            "Folk Music (also under various other categories)",
            "American Folk Revival",
            "Anti-Folk",
            "British Folk Revival",
            "Contemporary Folk",
            "Filk Music",
            "Freak Folk",
            "Indie Folk",
            "Industrial Folk",
            "Neofolk",
            "Progressive Folk",
            "Psychedelic Folk",
            "Sung Poetry",
            "Techno-Folk",
            "German Folk",
            "German Pop",
            "Fitness & Workout",
            "Hip-Hop/Rap",
            "Alternative Rap",
            "Avant-Garde",
            "Bounce",
            "Chap Hop",
            "Christian Hip Hop",
            "Conscious Hip Hop",
            "Country-Rap",
            "Grunk",
            "Crunkcore",
            "Cumbia Rap",
            "Dirty South",
            "East Coast",
            "Brick City Club",
            "Hardcore Hip Hop",
            "Mafioso Rap",
            "New Jersey Hip Hop",
            "Freestyle Rap",
            "G-Funk",
            "Gangsta Rap",
            "Golden Age",
            "Grime",
            "Hardcore Rap",
            "Hip-Hop",
            "Hip Pop",
            "Horrorcore",
            "Hyphy",
            "Industrial Hip Hop",
            "Instrumental Hip Hop",
            "Jazz Rap",
            "Latin Rap",
            "Low Bap",
            "Lyrical Hip Hop",
            "Merenrap",
            "Midwest Hip Hop",
            "Chicago Hip Hop",
            "Detroit Hip Hop",
            "Horrorcore",
            "St. Louis Hip Hop",
            "Twin Cities Hip Hop",
            "Motswako",
            "Nerdcore",
            "New Jack Swing",
            "New School Hip Hop",
            "Old School Rap",
            "Rap",
            "Trap",
            "Turntablism",
            "Underground Rap",
            "West Coast Rap",
            "Holiday",
            "Chanukah",
            "Christmas",
            "Christmas: Children’s",
            "Christmas: Classic",
            "Christmas: Classical",
            "Christmas: Comedy",
            "Christmas: Jazz",
            "Christmas: Modern",
            "Christmas: Pop",
            "Christmas: R&B",
            "Christmas: Religious",
            "Christmas: Rock",
            "Easter",
            "Halloween",
            "Holiday: Other",
            "Thanksgiving",
            "Indie Pop",
            "Industrial",
            "Aggrotech",
            "Coldwave",
            "Cybergrind",
            "Dark Electro",
            "Death Industrial",
            "Electro-Industrial",
            "Electronic Body Music",
            "Futurepop",
            "Industrial Metal",
            "Neue Deutsche Härte",
            "Industrial Rock",
            "Noise",
            "Japanoise",
            "Power Electronics",
            "Power Noise",
            "Witch House",
            "Inspirational – Christian & Gospel",
            "CCM",
            "Christian Metal",
            "Christian Pop",
            "Christian Rap",
            "Christian Rock",
            "Classic Christian",
            "Contemporary Gospel",
            "Gospel",
            "Christian & Gospel",
            "Praise & Worship",
            "Qawwali",
            "Southern Gospel",
            "Traditional Gospel",
            "Instrumental",
            "March (Marching Band)",
            "J-Pop (also under ‘Asian’)",
            "J-Rock",
            "J-Synth",
            "J-Ska",
            "J-Punk",
            "Jazz",
            "Acid Jazz",
            "Afro-Cuban Jazz",
            "Avant-Garde Jazz",
            "Bebop",
            "Big Band",
            "Blue Note",
            "British Dance Band (Jazz)",
            "Cape Jazz",
            "Chamber Jazz",
            "Contemporary Jazz",
            "Continental Jazz",
            "Cool Jazz",
            "Crossover Jazz",
            "Dark Jazz",
            "Dixieland",
            "Early Jazz",
            "Electro Swing (Jazz)",
            "Ethio-jazz",
            "Ethno-Jazz",
            "European Free Jazz",
            "Free Funk (Avant-Garde / Funk Jazz)",
            "Free Jazz",
            "Fusion",
            "Gypsy Jazz",
            "Hard Bop",
            "Indo Jazz",
            "Jazz Blues",
            "Jazz-Funk (see Free Funk)",
            "Jazz-Fusion",
            "Jazz Rap",
            "Jazz Rock",
            "Kansas City Jazz",
            "Latin Jazz",
            "M-Base Jazz",
            "Mainstream Jazz",
            "Modal Jazz",
            "Neo-Bop",
            "Neo-Swing",
            "Nu Jazz",
            "Orchestral Jazz",
            "Post-Bop",
            "Punk Jazz",
            "Ragtime",
            "Ska Jazz",
            "Skiffle (also Folk)",
            "Smooth Jazz",
            "Soul Jazz",
            "Swing Jazz",
            "Straight-Ahead Jazz",
            "Trad Jazz",
            "Third Stream",
            "Jazz-Funk",
            "Free Jazz",
            "West Coast Jazz",
            "K-Pop (also under ‘Asian’)",
            "Karaoke",
            "Kayokyoku",
            "Latin",
            "Alternativo & Rock Latino",
            "Argentine Tango",
            "Bachata",
            "Baithak Gana",
            "Baladas y Boleros",
            "Bolero",
            "Bossa Nova",
            "Brazilian",
            "Axé",
            "Bossa Nova",
            "Brazilian Rock",
            "Brega",
            "Choro",
            "Forró",
            "Frevo",
            "Funk Carioca",
            "Lambada",
            "Maracatu",
            "Música Popular Brasileira",
            "Música Sertaneja",
            "Pagode",
            "Samba",
            "Samba Rock",
            "Tecnobrega",
            "Tropicalia",
            "Zouk-Lambada",
            "Chicha",
            "Criolla",
            "Contemporary Latin",
            "Cumbia",
            "Flamenco / Spanish Flamenco",
            "Huayno",
            "Joropo ",
            "Latin Jazz",
            "Mambo (Cuba)",
            "Mariachi",
            "Merengue Típico",
            "Nuevo Flamenco",
            "Pop Latino",
            "Portuguese Fado",
            "Punta",
            "Punta Rock",
            "Ranchera",
            "Raíces",
            "Raison",
            "Reggaeton y Hip-Hop",
            "Regional Mexicano",
            "Salsa y Tropical",
            "Soca",
            "Son",
            "Tejano",
            "Timba",
            "Twoubadou",
            "Vallenato",
            "Zouk",
            "Metal",
            "Heavy Metal",
            "Speed Metal",
            "Thrash Metal",
            "Power Metal",
            "Death Metal",
            "Black Metal",
            "Pagan Metal",
            "Viking Metal",
            "Folk Metal",
            "Symphonic Metal",
            "Gothic Metal",
            "Glam Metal",
            "Hair Metal",
            "Doom Metal",
            "Groove Metal",
            "Industrial Metal",
            "Modern Metal",
            "Neoclassical Metal",
            "New Wave Of British Heavy Metal",
            "Post Metal",
            "Progressive Metal",
            "Avantgarde Metal",
            "Sludge",
            "Djent",
            "Drone",
            "Kawaii Metal",
            "Pirate Metal",
            "Nu Metal",
            "Neue Deutsche Härte",
            "Math Metal",
            "Crossover",
            "Grindcore",
            "Hardcore",
            "Metalcore",
            "Deathcore",
            "Post Hardcore",
            "Mathcore",
            "New Age",
            "Environmental",
            "Healing",
            "Meditation",
            "Nature",
            "Relaxation",
            "Travel",
            "Opera",
            "Pop",
            "Adult Contemporary",
            "Arab Pop",
            "Baroque",
            "Britpop",
            "Bubblegum Pop",
            "Chamber Pop",
            "Chanson",
            "Christian Pop",
            "Classical Crossover",
            "Europop",
            "Austropop",
            "Balkan Pop",
            "French Pop",
            "Latin Pop",
            "Laïkó",
            "Nederpop",
            "Russian Pop",
            "Dance Pop",
            "Dream Pop",
            "Electro Pop",
            "Iranian Pop",
            "Jangle Pop",
            "Latin Ballad",
            "Levenslied",
            "Louisiana Swamp Pop",
            "Mexican Pop",
            "Motorpop",
            "New Romanticism",
            "Orchestral Pop",
            "Pop Rap",
            "Popera",
            "Pop/Rock",
            "Pop Punk",
            "Power Pop",
            "Psychedelic Pop",
            "Schlager",
            "Soft Rock",
            "Sophisti-Pop",
            "Space Age Pop",
            "Sunshine Pop",
            "Surf Pop",
            "Synthpop",
            "Teen Pop",
            "Traditional Pop Music",
            "Turkish Pop",
            "Vispop",
            "Wonky Pop",
            "Post-Disco",
            "Boogie",
            "Dance-pop",
            "Progressive",
            "Progressive House / Trance",
            "Disco House",
            "Dream House",
            "Space House",
            "Japanese House",
            "Bounce / Scouse House",
            "Progressive Breaks",
            "Progressive Drum & Bass",
            "Progressive Techno",
            "R&B/Soul",
            "(Carolina) Beach Music",
            "Contemporary R&B",
            "Disco",
            "Doo Wop",
            "Funk",
            "Modern Soul",
            "Motown",
            "Neo-Soul",
            "Northern Soul",
            "Psychedelic Soul",
            "Quiet Storm",
            "Soul",
            "Soul Blues",
            "Southern Soul",
            "Reggae",
            "2-Tone",
            "Dub",
            "Roots Reggae",
            "Reggae Fusion",
            "Reggae en Español",
            "Spanish Reggae",
            "Reggae 110",
            "Reggae Bultrón",
            "Romantic Flow",
            "Lovers Rock",
            "Raggamuffin",
            "Ragga",
            "Dancehall",
            "Ska",
            "2 Tone",
            "Dub",
            "Rocksteady",
            "Reggae Dancehall",
            "Rock",
            "Acid Rock",
            "Adult-Oriented Rock",
            "Afro Punk",
            "Adult Alternative",
            "Alternative Rock",
            "American Traditional Rock",
            "Anatolian Rock",
            "Arena Rock",
            "Art Rock",
            "Blues-Rock",
            "British Invasion",
            "Cock Rock",
            "Death Metal / Black Metal",
            "Doom Metal",
            "Glam Rock",
            "Gothic Metal",
            "Grind Core",
            "Hair Metal",
            "Hard Rock",
            "Math Metal",
            "Math Rock",
            "Metal",
            "Metal Core",
            "Noise Rock (genre – Japanoise)",
            "Jam Bands",
            "Post Punk",
            "Post Rock",
            "Prog-Rock/Art Rock",
            "Progressive Metal",
            "Psychedelic",
            "Rock & Roll",
            "Rockabilly",
            "Roots Rock",
            "Singer/Songwriter",
            "Southern Rock",
            "Spazzcore",
            "Stoner Metal (duuuude)",
            "Surf",
            "Technical Death Metal",
            "Tex-Mex",
            "Thrash Metal",
            "Time Lord Rock (Trock)",
            "Trip-hop",
            "Yacht Rock (soft rock)",
            "Singer/Songwriter",
            "Alternative Folk",
            "Contemporary Folk",
            "Contemporary Singer/Songwriter",
            "Indie Folk",
            "Folk-Rock",
            "Love Song (Chanson)",
            "New Acoustic",
            "Traditional Folk",
            "Soundtrack",
            "Foreign Cinema",
            "Movie Soundtrack",
            "Musicals",
            "Original Score",
            "Soundtrack",
            "TV Soundtrack",
            "Spoken Word",
            "Tex-Mex / Tejano",
            "Chicano",
            "Classic",
            "Conjunto",
            "Conjunto Progressive",
            "New Mex",
            "Tex-Mex",
            "Vocal",
            "A cappella",
            "Barbershop",
            "Cantique (sacred vocal)",
            "Doo-wop",
            "Gregorian Chant",
            "Standards",
            "Traditional Pop",
            "Vocal Jazz",
            "Vocal Pop",
            "Yodel",
            "World",
            "Africa",
            "African Heavy Metal",
            "African Hip Hop",
            "Afro-Beat",
            "Afro-House",
            "Afro-Pop",
            "Apala (or akpala)",
            "Benga",
            "Bikutsi",
            "Bongo Flava",
            "Cape Jazz",
            "Chimurenga",
            "Coupé-Décalé",
            "Fuji Music",
            "Genge",
            "Gnawa (hypnotic trance)",
            "Highlife",
            "Hiplife",
            "Isicathamiya",
            "Jit",
            "Jùjú",
            "Kapuka",
            "Kizomba",
            "Kuduro",
            "Kwaito",
            "Kwela",
            "Lingala (Rumba Lingala / Congolese Rumba)",
            "Makossa",
            "Maloya",
            "Marrabenta",
            "Mbalax",
            "Mbaqanga",
            "Mbube",
            "Morna",
            "Museve",
            "Negro Spiritual",
            "Palm-Wine",
            "Raï",
            "Sakara",
            "Sega",
            "Seggae",
            "Semba",
            "Soukous",
            "Taarab",
            "Zouglou",
            "Asia",
            "Anison",
            "Baithak Gana",
            "C-Pop",
            "CityPop",
            "Cantopop",
            "Enka",
            "Hong Kong English Pop",
            "Fann At-Tanbura",
            "Fijiri",
            "J-Pop",
            "Japanese Pop",
            "K-Pop",
            "Khaliji",
            "Kayōkyoku",
            "Korean Pop",
            "Liwa",
            "Mandopop",
            "Onkyokei",
            "Taiwanese Pop",
            "Sawt",
            "Australia",
            "Cajun",
            "Calypso",
            "Caribbean",
            "Chutney",
            "Chutney Soca",
            "Compas",
            "Mambo",
            "Merengue",
            "Méringue",
            "Carnatic (Karnataka Sanghetha)",
            "Celtic",
            "Celtic Folk",
            "Contemporary Celtic",
            "Coupé-décalé – Congo",
            "Dangdut",
            "Drinking Songs",
            "Drone",
            "Europe",
            "Europe – Greece: Laiko, Entechno, Rebetika",
            "France",
            "Hawaii",
            "Japan",
            "Klezmer",
            "Mbalax – Senegal",
            "Middle East",
            "North America",
            "Ode",
            "Piphat – Thailand",
            "Polka",
            "Soca",
            "South Africa",
            "South America",
            "South / Southeast Asia",
            "Baila",
            "Bhangra",
            "Bhojpuri",
            "Dangdut",
            "Filmi",
            "Indian Pop",
            "Hindustani",
            "Indian Ghazal",
            "Lavani",
            "Luk Thung",
            "Luk Krung",
            "Manila Sound",
            "Morlam",
            "Pinoy Pop",
            "Pop Sunda",
            "Ragini",
            "Thai Pop",
            "Traditional Celtic",
            "Worldbeat",
            "Zydeco"});
            this.genreCombo.Location = new System.Drawing.Point(97, 164);
            this.genreCombo.Name = "genreCombo";
            this.genreCombo.Size = new System.Drawing.Size(275, 24);
            this.genreCombo.TabIndex = 3;
            this.genreCombo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.genreCombo_KeyDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.genreCombo);
            this.Controls.Add(this.findSongButton);
            this.Controls.Add(this.clearSongButton);
            this.Controls.Add(this.urlX);
            this.Controls.Add(this.yearX);
            this.Controls.Add(this.artistX);
            this.Controls.Add(this.titleX);
            this.Controls.Add(this.allSongsButton);
            this.Controls.Add(this.detailText);
            this.Controls.Add(this.songText);
            this.Controls.Add(this.songList);
            this.Controls.Add(this.addSongButton);
            this.Controls.Add(this.outputText);
            this.Controls.Add(this.urlLabel);
            this.Controls.Add(this.urlText);
            this.Controls.Add(this.yearLabel);
            this.Controls.Add(this.yearText);
            this.Controls.Add(this.genreLabel);
            this.Controls.Add(this.artistLabel);
            this.Controls.Add(this.artistText);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.titleText);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Video Manager";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox titleText;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label artistLabel;
        private System.Windows.Forms.TextBox artistText;
        private System.Windows.Forms.Label genreLabel;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.TextBox yearText;
        private System.Windows.Forms.Label urlLabel;
        private System.Windows.Forms.TextBox urlText;
        private System.Windows.Forms.TextBox outputText;
        private System.Windows.Forms.Button addSongButton;
        private System.Windows.Forms.ListBox songList;
        private System.Windows.Forms.Label songText;
        private System.Windows.Forms.Label detailText;
        private System.Windows.Forms.Button allSongsButton;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label titleX;
        private System.Windows.Forms.Label artistX;
        private System.Windows.Forms.Label yearX;
        private System.Windows.Forms.Label urlX;
        private System.Windows.Forms.Button clearSongButton;
        private System.Windows.Forms.Button findSongButton;
        private System.Windows.Forms.ComboBox genreCombo;
    }
}

