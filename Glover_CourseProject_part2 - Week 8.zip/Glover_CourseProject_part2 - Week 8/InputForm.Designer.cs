﻿namespace Glover_CourseProject_part2
{
    partial class InputForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FirstNameLabel = new System.Windows.Forms.Label();
            this.FirstNameTextbox = new System.Windows.Forms.TextBox();
            this.LastNameTextbox = new System.Windows.Forms.TextBox();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.SSNTextbox = new System.Windows.Forms.TextBox();
            this.SSNLabel = new System.Windows.Forms.Label();
            this.HireDateTextbox = new System.Windows.Forms.TextBox();
            this.HireDateLabel = new System.Windows.Forms.Label();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.FirstNameXLabel = new System.Windows.Forms.Label();
            this.LastNameXLabel = new System.Windows.Forms.Label();
            this.SSNXLabel = new System.Windows.Forms.Label();
            this.HireDateXLabel = new System.Windows.Forms.Label();
            this.BenefitsGroupBox = new System.Windows.Forms.GroupBox();
            this.VacationXLabel = new System.Windows.Forms.Label();
            this.LifeXLabel = new System.Windows.Forms.Label();
            this.HealthXLabel = new System.Windows.Forms.Label();
            this.VacationDaysTextbox = new System.Windows.Forms.TextBox();
            this.VacationDaysLabel = new System.Windows.Forms.Label();
            this.LifeInsuranceTextbox = new System.Windows.Forms.TextBox();
            this.LifeInsuranceLabel = new System.Windows.Forms.Label();
            this.HealthInsuranceTextbox = new System.Windows.Forms.TextBox();
            this.HealthInsuranceLabel = new System.Windows.Forms.Label();
            this.HourlyRadioButton = new System.Windows.Forms.RadioButton();
            this.SalaryRadioButton = new System.Windows.Forms.RadioButton();
            this.HourlyPayTextbox = new System.Windows.Forms.TextBox();
            this.HourlyPayLabel = new System.Windows.Forms.Label();
            this.HoursWorkedTextbox = new System.Windows.Forms.TextBox();
            this.HoursWorkedLabel = new System.Windows.Forms.Label();
            this.PayXLabel = new System.Windows.Forms.Label();
            this.WorkedXLabel = new System.Windows.Forms.Label();
            this.SalaryTextbox = new System.Windows.Forms.TextBox();
            this.SalaryLabel = new System.Windows.Forms.Label();
            this.SalaryXlabel = new System.Windows.Forms.Label();
            this.HireDateExampleLabel = new System.Windows.Forms.Label();
            this.SSNExampleLabel = new System.Windows.Forms.Label();
            this.BenefitsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.Location = new System.Drawing.Point(38, 71);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(195, 38);
            this.FirstNameLabel.TabIndex = 0;
            this.FirstNameLabel.Text = "First Name :";
            // 
            // FirstNameTextbox
            // 
            this.FirstNameTextbox.Location = new System.Drawing.Point(291, 71);
            this.FirstNameTextbox.Name = "FirstNameTextbox";
            this.FirstNameTextbox.Size = new System.Drawing.Size(342, 45);
            this.FirstNameTextbox.TabIndex = 2;
            this.FirstNameTextbox.TextChanged += new System.EventHandler(this.FirstNameTextbox_TextChanged);
            this.FirstNameTextbox.Enter += new System.EventHandler(this.FirstNameTextbox_Enter);
            this.FirstNameTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FirstNameTextbox_KeyDown);
            this.FirstNameTextbox.Leave += new System.EventHandler(this.FirstNameTextbox_Leave);
            // 
            // LastNameTextbox
            // 
            this.LastNameTextbox.Location = new System.Drawing.Point(291, 140);
            this.LastNameTextbox.Name = "LastNameTextbox";
            this.LastNameTextbox.Size = new System.Drawing.Size(342, 45);
            this.LastNameTextbox.TabIndex = 3;
            this.LastNameTextbox.TextChanged += new System.EventHandler(this.LastNameTextbox_TextChanged);
            this.LastNameTextbox.Enter += new System.EventHandler(this.LastNameTextbox_Enter);
            this.LastNameTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LastNameTextbox_KeyDown);
            this.LastNameTextbox.Leave += new System.EventHandler(this.LastNameTextbox_Leave);
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.Location = new System.Drawing.Point(38, 140);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(193, 38);
            this.LastNameLabel.TabIndex = 2;
            this.LastNameLabel.Text = "Last Name :";
            // 
            // SSNTextbox
            // 
            this.SSNTextbox.Location = new System.Drawing.Point(291, 205);
            this.SSNTextbox.Name = "SSNTextbox";
            this.SSNTextbox.Size = new System.Drawing.Size(342, 45);
            this.SSNTextbox.TabIndex = 4;
            this.SSNTextbox.TextChanged += new System.EventHandler(this.SSNTextbox_TextChanged);
            this.SSNTextbox.Enter += new System.EventHandler(this.SSNTextbox_Enter);
            this.SSNTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SSNTextbox_KeyDown);
            this.SSNTextbox.Leave += new System.EventHandler(this.SSNTextbox_Leave);
            // 
            // SSNLabel
            // 
            this.SSNLabel.AutoSize = true;
            this.SSNLabel.Location = new System.Drawing.Point(38, 208);
            this.SSNLabel.Name = "SSNLabel";
            this.SSNLabel.Size = new System.Drawing.Size(103, 38);
            this.SSNLabel.TabIndex = 4;
            this.SSNLabel.Text = "SSN :";
            // 
            // HireDateTextbox
            // 
            this.HireDateTextbox.Location = new System.Drawing.Point(291, 269);
            this.HireDateTextbox.Name = "HireDateTextbox";
            this.HireDateTextbox.Size = new System.Drawing.Size(342, 45);
            this.HireDateTextbox.TabIndex = 5;
            this.HireDateTextbox.TextChanged += new System.EventHandler(this.HireDateTextbox_TextChanged);
            this.HireDateTextbox.Enter += new System.EventHandler(this.HireDateTextbox_Enter);
            this.HireDateTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.HireDateTextbox_KeyDown);
            this.HireDateTextbox.Leave += new System.EventHandler(this.HireDateTextbox_Leave);
            // 
            // HireDateLabel
            // 
            this.HireDateLabel.AutoSize = true;
            this.HireDateLabel.Location = new System.Drawing.Point(38, 272);
            this.HireDateLabel.Name = "HireDateLabel";
            this.HireDateLabel.Size = new System.Drawing.Size(173, 38);
            this.HireDateLabel.TabIndex = 6;
            this.HireDateLabel.Text = "Hire Date :";
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(203, 702);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(179, 50);
            this.SubmitButton.TabIndex = 9;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(416, 702);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(179, 50);
            this.ExitButton.TabIndex = 10;
            this.ExitButton.Text = "Cancel";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // FirstNameXLabel
            // 
            this.FirstNameXLabel.AutoSize = true;
            this.FirstNameXLabel.BackColor = System.Drawing.SystemColors.Window;
            this.FirstNameXLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.FirstNameXLabel.Location = new System.Drawing.Point(593, 74);
            this.FirstNameXLabel.Name = "FirstNameXLabel";
            this.FirstNameXLabel.Size = new System.Drawing.Size(39, 38);
            this.FirstNameXLabel.TabIndex = 7;
            this.FirstNameXLabel.Text = "X";
            this.FirstNameXLabel.Visible = false;
            this.FirstNameXLabel.Click += new System.EventHandler(this.FirstNameXLabel_Click);
            // 
            // LastNameXLabel
            // 
            this.LastNameXLabel.AutoSize = true;
            this.LastNameXLabel.BackColor = System.Drawing.SystemColors.Window;
            this.LastNameXLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.LastNameXLabel.Location = new System.Drawing.Point(593, 143);
            this.LastNameXLabel.Name = "LastNameXLabel";
            this.LastNameXLabel.Size = new System.Drawing.Size(39, 38);
            this.LastNameXLabel.TabIndex = 8;
            this.LastNameXLabel.Text = "X";
            this.LastNameXLabel.Visible = false;
            this.LastNameXLabel.Click += new System.EventHandler(this.LastNameXLabel_Click);
            // 
            // SSNXLabel
            // 
            this.SSNXLabel.AutoSize = true;
            this.SSNXLabel.BackColor = System.Drawing.SystemColors.Window;
            this.SSNXLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.SSNXLabel.Location = new System.Drawing.Point(593, 208);
            this.SSNXLabel.Name = "SSNXLabel";
            this.SSNXLabel.Size = new System.Drawing.Size(39, 38);
            this.SSNXLabel.TabIndex = 9;
            this.SSNXLabel.Text = "X";
            this.SSNXLabel.Visible = false;
            this.SSNXLabel.Click += new System.EventHandler(this.SSNXLabel_Click);
            // 
            // HireDateXLabel
            // 
            this.HireDateXLabel.AutoSize = true;
            this.HireDateXLabel.BackColor = System.Drawing.SystemColors.Window;
            this.HireDateXLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.HireDateXLabel.Location = new System.Drawing.Point(593, 272);
            this.HireDateXLabel.Name = "HireDateXLabel";
            this.HireDateXLabel.Size = new System.Drawing.Size(39, 38);
            this.HireDateXLabel.TabIndex = 10;
            this.HireDateXLabel.Text = "X";
            this.HireDateXLabel.Visible = false;
            this.HireDateXLabel.Click += new System.EventHandler(this.HireDateXLabel_Click);
            // 
            // BenefitsGroupBox
            // 
            this.BenefitsGroupBox.Controls.Add(this.VacationXLabel);
            this.BenefitsGroupBox.Controls.Add(this.LifeXLabel);
            this.BenefitsGroupBox.Controls.Add(this.HealthXLabel);
            this.BenefitsGroupBox.Controls.Add(this.VacationDaysTextbox);
            this.BenefitsGroupBox.Controls.Add(this.VacationDaysLabel);
            this.BenefitsGroupBox.Controls.Add(this.LifeInsuranceTextbox);
            this.BenefitsGroupBox.Controls.Add(this.LifeInsuranceLabel);
            this.BenefitsGroupBox.Controls.Add(this.HealthInsuranceTextbox);
            this.BenefitsGroupBox.Controls.Add(this.HealthInsuranceLabel);
            this.BenefitsGroupBox.Location = new System.Drawing.Point(32, 458);
            this.BenefitsGroupBox.Name = "BenefitsGroupBox";
            this.BenefitsGroupBox.Size = new System.Drawing.Size(722, 231);
            this.BenefitsGroupBox.TabIndex = 8;
            this.BenefitsGroupBox.TabStop = false;
            this.BenefitsGroupBox.Text = "Benefits";
            // 
            // VacationXLabel
            // 
            this.VacationXLabel.AutoSize = true;
            this.VacationXLabel.BackColor = System.Drawing.SystemColors.Window;
            this.VacationXLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.VacationXLabel.Location = new System.Drawing.Point(585, 171);
            this.VacationXLabel.Name = "VacationXLabel";
            this.VacationXLabel.Size = new System.Drawing.Size(39, 38);
            this.VacationXLabel.TabIndex = 13;
            this.VacationXLabel.Text = "X";
            this.VacationXLabel.Visible = false;
            this.VacationXLabel.Click += new System.EventHandler(this.VacationXLabel_Click);
            // 
            // LifeXLabel
            // 
            this.LifeXLabel.AutoSize = true;
            this.LifeXLabel.BackColor = System.Drawing.SystemColors.Window;
            this.LifeXLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.LifeXLabel.Location = new System.Drawing.Point(585, 105);
            this.LifeXLabel.Name = "LifeXLabel";
            this.LifeXLabel.Size = new System.Drawing.Size(39, 38);
            this.LifeXLabel.TabIndex = 12;
            this.LifeXLabel.Text = "X";
            this.LifeXLabel.Visible = false;
            this.LifeXLabel.Click += new System.EventHandler(this.LifeXLabel_Click);
            // 
            // HealthXLabel
            // 
            this.HealthXLabel.AutoSize = true;
            this.HealthXLabel.BackColor = System.Drawing.SystemColors.Window;
            this.HealthXLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.HealthXLabel.Location = new System.Drawing.Point(585, 44);
            this.HealthXLabel.Name = "HealthXLabel";
            this.HealthXLabel.Size = new System.Drawing.Size(39, 38);
            this.HealthXLabel.TabIndex = 11;
            this.HealthXLabel.Text = "X";
            this.HealthXLabel.Visible = false;
            this.HealthXLabel.Click += new System.EventHandler(this.HealthXLabel_Click);
            // 
            // VacationDaysTextbox
            // 
            this.VacationDaysTextbox.CausesValidation = false;
            this.VacationDaysTextbox.Location = new System.Drawing.Point(283, 168);
            this.VacationDaysTextbox.Name = "VacationDaysTextbox";
            this.VacationDaysTextbox.Size = new System.Drawing.Size(341, 45);
            this.VacationDaysTextbox.TabIndex = 2;
            this.VacationDaysTextbox.TextChanged += new System.EventHandler(this.VacationDaysTextbox_TextChanged);
            this.VacationDaysTextbox.Enter += new System.EventHandler(this.VacationDaysTextbox_Enter);
            this.VacationDaysTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.VacationDaysTextbox_KeyDown);
            this.VacationDaysTextbox.Leave += new System.EventHandler(this.VacationDaysTextbox_Leave);
            // 
            // VacationDaysLabel
            // 
            this.VacationDaysLabel.AutoSize = true;
            this.VacationDaysLabel.CausesValidation = false;
            this.VacationDaysLabel.Location = new System.Drawing.Point(5, 171);
            this.VacationDaysLabel.Name = "VacationDaysLabel";
            this.VacationDaysLabel.Size = new System.Drawing.Size(238, 38);
            this.VacationDaysLabel.TabIndex = 6;
            this.VacationDaysLabel.Text = "Vacation Days:";
            // 
            // LifeInsuranceTextbox
            // 
            this.LifeInsuranceTextbox.CausesValidation = false;
            this.LifeInsuranceTextbox.Location = new System.Drawing.Point(283, 102);
            this.LifeInsuranceTextbox.Name = "LifeInsuranceTextbox";
            this.LifeInsuranceTextbox.Size = new System.Drawing.Size(341, 45);
            this.LifeInsuranceTextbox.TabIndex = 1;
            this.LifeInsuranceTextbox.TextChanged += new System.EventHandler(this.LifeInsuranceTextbox_TextChanged);
            this.LifeInsuranceTextbox.Enter += new System.EventHandler(this.LifeInsuranceTextbox_Enter);
            this.LifeInsuranceTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LifeInsuranceTextbox_KeyDown);
            this.LifeInsuranceTextbox.Leave += new System.EventHandler(this.LifeInsuranceTextbox_Leave);
            // 
            // LifeInsuranceLabel
            // 
            this.LifeInsuranceLabel.AutoSize = true;
            this.LifeInsuranceLabel.CausesValidation = false;
            this.LifeInsuranceLabel.Location = new System.Drawing.Point(5, 105);
            this.LifeInsuranceLabel.Name = "LifeInsuranceLabel";
            this.LifeInsuranceLabel.Size = new System.Drawing.Size(230, 38);
            this.LifeInsuranceLabel.TabIndex = 4;
            this.LifeInsuranceLabel.Text = "Life Insurance:";
            // 
            // HealthInsuranceTextbox
            // 
            this.HealthInsuranceTextbox.CausesValidation = false;
            this.HealthInsuranceTextbox.Location = new System.Drawing.Point(283, 41);
            this.HealthInsuranceTextbox.Name = "HealthInsuranceTextbox";
            this.HealthInsuranceTextbox.Size = new System.Drawing.Size(341, 45);
            this.HealthInsuranceTextbox.TabIndex = 0;
            this.HealthInsuranceTextbox.TextChanged += new System.EventHandler(this.HealthInsuranceTextbox_TextChanged);
            this.HealthInsuranceTextbox.Enter += new System.EventHandler(this.HealthInsuranceTextbox_Enter);
            this.HealthInsuranceTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.HealthInsuranceTextbox_KeyDown);
            this.HealthInsuranceTextbox.Leave += new System.EventHandler(this.HealthInsuranceTextbox_Leave);
            // 
            // HealthInsuranceLabel
            // 
            this.HealthInsuranceLabel.AutoSize = true;
            this.HealthInsuranceLabel.CausesValidation = false;
            this.HealthInsuranceLabel.Location = new System.Drawing.Point(5, 44);
            this.HealthInsuranceLabel.Name = "HealthInsuranceLabel";
            this.HealthInsuranceLabel.Size = new System.Drawing.Size(272, 38);
            this.HealthInsuranceLabel.TabIndex = 2;
            this.HealthInsuranceLabel.Text = "Health Insurance:";
            // 
            // HourlyRadioButton
            // 
            this.HourlyRadioButton.AutoSize = true;
            this.HourlyRadioButton.Checked = true;
            this.HourlyRadioButton.Location = new System.Drawing.Point(45, 10);
            this.HourlyRadioButton.Name = "HourlyRadioButton";
            this.HourlyRadioButton.Size = new System.Drawing.Size(133, 42);
            this.HourlyRadioButton.TabIndex = 0;
            this.HourlyRadioButton.TabStop = true;
            this.HourlyRadioButton.Text = "Hourly";
            this.HourlyRadioButton.UseVisualStyleBackColor = true;
            this.HourlyRadioButton.CheckedChanged += new System.EventHandler(this.HourlyRadioButton_CheckedChanged);
            // 
            // SalaryRadioButton
            // 
            this.SalaryRadioButton.AutoSize = true;
            this.SalaryRadioButton.Location = new System.Drawing.Point(244, 10);
            this.SalaryRadioButton.Name = "SalaryRadioButton";
            this.SalaryRadioButton.Size = new System.Drawing.Size(131, 42);
            this.SalaryRadioButton.TabIndex = 1;
            this.SalaryRadioButton.Text = "Salary";
            this.SalaryRadioButton.UseVisualStyleBackColor = true;
            this.SalaryRadioButton.CheckedChanged += new System.EventHandler(this.SalaryRadioButton_CheckedChanged);
            // 
            // HourlyPayTextbox
            // 
            this.HourlyPayTextbox.Location = new System.Drawing.Point(292, 333);
            this.HourlyPayTextbox.Name = "HourlyPayTextbox";
            this.HourlyPayTextbox.Size = new System.Drawing.Size(342, 45);
            this.HourlyPayTextbox.TabIndex = 6;
            this.HourlyPayTextbox.TextChanged += new System.EventHandler(this.HourlyPayTextbox_TextChanged);
            this.HourlyPayTextbox.Enter += new System.EventHandler(this.HourlyPayTextbox_Enter);
            this.HourlyPayTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.HourlyPayTextbox_KeyDown);
            this.HourlyPayTextbox.Leave += new System.EventHandler(this.HourlyPayTextbox_Leave);
            // 
            // HourlyPayLabel
            // 
            this.HourlyPayLabel.AutoSize = true;
            this.HourlyPayLabel.Location = new System.Drawing.Point(37, 333);
            this.HourlyPayLabel.Name = "HourlyPayLabel";
            this.HourlyPayLabel.Size = new System.Drawing.Size(196, 38);
            this.HourlyPayLabel.TabIndex = 13;
            this.HourlyPayLabel.Text = "Hourly Pay :";
            // 
            // HoursWorkedTextbox
            // 
            this.HoursWorkedTextbox.Location = new System.Drawing.Point(290, 394);
            this.HoursWorkedTextbox.Name = "HoursWorkedTextbox";
            this.HoursWorkedTextbox.Size = new System.Drawing.Size(342, 45);
            this.HoursWorkedTextbox.TabIndex = 7;
            this.HoursWorkedTextbox.TextChanged += new System.EventHandler(this.HoursWorkedTextbox_TextChanged);
            this.HoursWorkedTextbox.Enter += new System.EventHandler(this.HoursWorkedTextbox_Enter);
            this.HoursWorkedTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.HoursWorkedTextbox_KeyDown);
            this.HoursWorkedTextbox.Leave += new System.EventHandler(this.HoursWorkedTextbox_Leave);
            // 
            // HoursWorkedLabel
            // 
            this.HoursWorkedLabel.AutoSize = true;
            this.HoursWorkedLabel.Location = new System.Drawing.Point(37, 394);
            this.HoursWorkedLabel.Name = "HoursWorkedLabel";
            this.HoursWorkedLabel.Size = new System.Drawing.Size(245, 38);
            this.HoursWorkedLabel.TabIndex = 15;
            this.HoursWorkedLabel.Text = "Hours Worked :";
            // 
            // PayXLabel
            // 
            this.PayXLabel.AutoSize = true;
            this.PayXLabel.BackColor = System.Drawing.SystemColors.Window;
            this.PayXLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.PayXLabel.Location = new System.Drawing.Point(593, 336);
            this.PayXLabel.Name = "PayXLabel";
            this.PayXLabel.Size = new System.Drawing.Size(39, 38);
            this.PayXLabel.TabIndex = 17;
            this.PayXLabel.Text = "X";
            this.PayXLabel.Visible = false;
            this.PayXLabel.Click += new System.EventHandler(this.PayXLabel_Click);
            // 
            // WorkedXLabel
            // 
            this.WorkedXLabel.AutoSize = true;
            this.WorkedXLabel.BackColor = System.Drawing.SystemColors.Window;
            this.WorkedXLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.WorkedXLabel.Location = new System.Drawing.Point(593, 394);
            this.WorkedXLabel.Name = "WorkedXLabel";
            this.WorkedXLabel.Size = new System.Drawing.Size(39, 38);
            this.WorkedXLabel.TabIndex = 18;
            this.WorkedXLabel.Text = "X";
            this.WorkedXLabel.Visible = false;
            this.WorkedXLabel.Click += new System.EventHandler(this.WorkedXLabel_Click);
            // 
            // SalaryTextbox
            // 
            this.SalaryTextbox.Location = new System.Drawing.Point(292, 335);
            this.SalaryTextbox.Name = "SalaryTextbox";
            this.SalaryTextbox.Size = new System.Drawing.Size(342, 45);
            this.SalaryTextbox.TabIndex = 11;
            this.SalaryTextbox.Visible = false;
            this.SalaryTextbox.TextChanged += new System.EventHandler(this.SalaryTextbox_TextChanged);
            this.SalaryTextbox.Enter += new System.EventHandler(this.SalaryTextbox_Enter);
            this.SalaryTextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SalaryTextbox_KeyDown);
            this.SalaryTextbox.Leave += new System.EventHandler(this.SalaryTextbox_Leave);
            // 
            // SalaryLabel
            // 
            this.SalaryLabel.AutoSize = true;
            this.SalaryLabel.Location = new System.Drawing.Point(39, 338);
            this.SalaryLabel.Name = "SalaryLabel";
            this.SalaryLabel.Size = new System.Drawing.Size(238, 38);
            this.SalaryLabel.TabIndex = 20;
            this.SalaryLabel.Text = "Annual Salary :";
            this.SalaryLabel.Visible = false;
            // 
            // SalaryXlabel
            // 
            this.SalaryXlabel.AutoSize = true;
            this.SalaryXlabel.BackColor = System.Drawing.SystemColors.Window;
            this.SalaryXlabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.SalaryXlabel.Location = new System.Drawing.Point(593, 338);
            this.SalaryXlabel.Name = "SalaryXlabel";
            this.SalaryXlabel.Size = new System.Drawing.Size(39, 38);
            this.SalaryXlabel.TabIndex = 21;
            this.SalaryXlabel.Text = "X";
            this.SalaryXlabel.Visible = false;
            this.SalaryXlabel.Click += new System.EventHandler(this.SalaryXlabel_Click);
            // 
            // HireDateExampleLabel
            // 
            this.HireDateExampleLabel.AutoSize = true;
            this.HireDateExampleLabel.BackColor = System.Drawing.SystemColors.Window;
            this.HireDateExampleLabel.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.HireDateExampleLabel.Location = new System.Drawing.Point(298, 272);
            this.HireDateExampleLabel.Name = "HireDateExampleLabel";
            this.HireDateExampleLabel.Size = new System.Drawing.Size(242, 38);
            this.HireDateExampleLabel.TabIndex = 22;
            this.HireDateExampleLabel.Text = "e.g. 01/01/2001";
            this.HireDateExampleLabel.Visible = false;
            // 
            // SSNExampleLabel
            // 
            this.SSNExampleLabel.AutoSize = true;
            this.SSNExampleLabel.BackColor = System.Drawing.SystemColors.Window;
            this.SSNExampleLabel.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.SSNExampleLabel.Location = new System.Drawing.Point(298, 208);
            this.SSNExampleLabel.Name = "SSNExampleLabel";
            this.SSNExampleLabel.Size = new System.Drawing.Size(300, 38);
            this.SSNExampleLabel.TabIndex = 23;
            this.SSNExampleLabel.Text = "e.g. XXX-XX-XXXX";
            this.SSNExampleLabel.Visible = false;
            // 
            // InputForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 38F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(805, 771);
            this.Controls.Add(this.SSNExampleLabel);
            this.Controls.Add(this.HireDateExampleLabel);
            this.Controls.Add(this.SalaryXlabel);
            this.Controls.Add(this.PayXLabel);
            this.Controls.Add(this.WorkedXLabel);
            this.Controls.Add(this.SalaryLabel);
            this.Controls.Add(this.HoursWorkedTextbox);
            this.Controls.Add(this.HoursWorkedLabel);
            this.Controls.Add(this.HourlyPayLabel);
            this.Controls.Add(this.SalaryRadioButton);
            this.Controls.Add(this.HourlyRadioButton);
            this.Controls.Add(this.BenefitsGroupBox);
            this.Controls.Add(this.HireDateXLabel);
            this.Controls.Add(this.SSNXLabel);
            this.Controls.Add(this.LastNameXLabel);
            this.Controls.Add(this.FirstNameXLabel);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.HireDateTextbox);
            this.Controls.Add(this.HireDateLabel);
            this.Controls.Add(this.SSNTextbox);
            this.Controls.Add(this.SSNLabel);
            this.Controls.Add(this.LastNameTextbox);
            this.Controls.Add(this.LastNameLabel);
            this.Controls.Add(this.FirstNameTextbox);
            this.Controls.Add(this.FirstNameLabel);
            this.Controls.Add(this.SalaryTextbox);
            this.Controls.Add(this.HourlyPayTextbox);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(7);
            this.Name = "InputForm";
            this.Text = "Input Form";
            this.BenefitsGroupBox.ResumeLayout(false);
            this.BenefitsGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FirstNameLabel;
        public System.Windows.Forms.TextBox FirstNameTextbox;
        public System.Windows.Forms.TextBox LastNameTextbox;
        private System.Windows.Forms.Label LastNameLabel;
        public System.Windows.Forms.TextBox SSNTextbox;
        private System.Windows.Forms.Label SSNLabel;
        public System.Windows.Forms.TextBox HireDateTextbox;
        private System.Windows.Forms.Label HireDateLabel;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Label FirstNameXLabel;
        private System.Windows.Forms.Label LastNameXLabel;
        private System.Windows.Forms.Label SSNXLabel;
        private System.Windows.Forms.Label HireDateXLabel;
        private System.Windows.Forms.GroupBox BenefitsGroupBox;
        public System.Windows.Forms.TextBox VacationDaysTextbox;
        private System.Windows.Forms.Label VacationDaysLabel;
        public System.Windows.Forms.TextBox LifeInsuranceTextbox;
        private System.Windows.Forms.Label LifeInsuranceLabel;
        public System.Windows.Forms.TextBox HealthInsuranceTextbox;
        private System.Windows.Forms.Label HealthInsuranceLabel;
        private System.Windows.Forms.Label VacationXLabel;
        private System.Windows.Forms.Label LifeXLabel;
        private System.Windows.Forms.Label HealthXLabel;
        public System.Windows.Forms.Button SubmitButton;
        public System.Windows.Forms.RadioButton HourlyRadioButton;
        public System.Windows.Forms.RadioButton SalaryRadioButton;
        public System.Windows.Forms.TextBox HourlyPayTextbox;
        public System.Windows.Forms.Label HourlyPayLabel;
        public System.Windows.Forms.TextBox HoursWorkedTextbox;
        private System.Windows.Forms.Label HoursWorkedLabel;
        private System.Windows.Forms.Label PayXLabel;
        private System.Windows.Forms.Label WorkedXLabel;
        public System.Windows.Forms.TextBox SalaryTextbox;
        public System.Windows.Forms.Label SalaryLabel;
        public System.Windows.Forms.Label SalaryXlabel;
        public System.Windows.Forms.Label HireDateExampleLabel;
        public System.Windows.Forms.Label SSNExampleLabel;
    }
}