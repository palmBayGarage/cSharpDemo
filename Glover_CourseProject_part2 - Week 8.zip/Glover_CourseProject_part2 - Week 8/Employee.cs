﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Glover_CourseProject_part2
{
    [Serializable]
    internal class Employee
    {
        #region Attributes
        // Attributes
        protected string firstName;
        protected string lastName;
        protected string ssn;
        protected string maskedSSN;
        protected DateTime hireDate;
        protected Benefits benefits;
        #endregion
        #region Constructors
        // Constructors
        #region Employee Contructor w/o Arguments
        public Employee()
        {
            firstName = "unknown";
            lastName = "unknown";
            ssn = "unknown";
            hireDate = DateTime.MinValue;
        }
        #endregion
        #region Employee Constructor w/ Arguments
        public Employee(string firstName, string lastName, string ssn, DateTime hireDate, Benefits benefits, string maskedSSN)
        {
            FirstName = firstName;
            LastName = lastName;
            SSN = ssn;
            MaskedSSN = maskedSSN;
            HireDate = hireDate;
            EmployeeBenefits = benefits;
            
        }
        #endregion
        #endregion
        #region Behaviors
        // Behaviors
        #region ToString() Behavior
        public override string ToString()
        {
            // Returns First Name + Last Name, SSN: XXX-XX-XXXX, Hire Date: XX/XX/XXXX
            return firstName + " " + lastName + ", SSN: " + maskedSSN + ", Hire Date: " +hireDate.ToShortDateString();
        }
        #endregion
        #region CalculatePay() Behavior
        public virtual double CalculatePay()
        {
            return 0.0;
        }
        #endregion
        #endregion
        #region Properties
        // Properties
        #region FirstName Property
        public string FirstName
        {
            get { return firstName; }
            set 
            {
                if (value.Length > 0)
                    firstName = value;
                else
                    firstName = "unknown";
            }
        }
        #endregion
        #region LastName Property
        public string LastName
        {
            get { return lastName; }
            set 
            { 
                if (value.Length > 0)
                    lastName = value; 
                else 
                    lastName = "unknown"; 
            }
        }
        #endregion
        #region SSN Property
        public string SSN
        {
            get { return ssn; }
            set
            {
                if (value.Length == 9 || value.Length == 11)
                    ssn = value;
                else
                    ssn = "unknown";
            }
        }
        #endregion
        #region MaskedSSN Property
        public string MaskedSSN
        {
            get { return maskedSSN; }
            set
            {
                if (value.Length == 9 || value.Length == 11)
                    maskedSSN = value;
                else
                    maskedSSN = "unknown";
            }
        }

        #endregion
        #region HireDate Property
        public DateTime HireDate
        {
            get { return hireDate; }
            set
            {
                if ((value.Year >= DateTime.Now.Year - 70) && value.Year <= DateTime.Now.Year + 1)
                    hireDate = value;
                else
                    hireDate = DateTime.MinValue;
            }
        }
        #endregion
        #region Employee Benefits Propertie
        public Benefits EmployeeBenefits
        {
            get { return benefits; }
            set { benefits = value; }
        }
        #endregion


        #endregion
    }
}
