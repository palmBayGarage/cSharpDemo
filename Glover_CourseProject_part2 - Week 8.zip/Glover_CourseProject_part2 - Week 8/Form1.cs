﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO; // Required to read and write files
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary; //"translator" to Binary
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Glover_CourseProject_part2
{
    public partial class MainForm : Form
    {
        //Global Variables
        const string FILENAME = "Employees.dat";
        #region MainForm
        public MainForm()
        {
            InitializeComponent();
        }
        #endregion
        #region Events
        #region Main Form Load Event
        private void MainForm_Load(object sender, EventArgs e)
        {
            ReadEmployeesFromFile();
        }
        #endregion
        #region Add Button Click Event
        private void AddButton_Click(object sender, EventArgs e) //add item to employee list box
        {
            Salary sal = new Salary();

            //Create New Input Form
            InputForm frmInput = new InputForm();

            using (frmInput)
            {
                DialogResult result = frmInput.ShowDialog();

                //if user presses cancel, close dialog box
                if (result == DialogResult.Cancel)
                {
                    return;
                }
                // get users input to be used to create an employee object
                string firstName = frmInput.FirstNameTextbox.Text;
                string lastName = frmInput.LastNameTextbox.Text;
                string SSN = frmInput.SSNTextbox.Text;
                string maskedSSN = MaskSSN(SSN);
                string date = frmInput.HireDateTextbox.Text;
                DateTime hireDate = DateTime.Parse(date);
                string healthInsurance = frmInput.HealthInsuranceTextbox.Text;
                double lifeInsurance = Double.Parse(frmInput.LifeInsuranceTextbox.Text);
                int vacationDays = Int32.Parse(frmInput.VacationDaysTextbox.Text);

                //create new Employee object
                Employee employee;

                //Create new Benefits object
                Benefits benefits = new Benefits(healthInsurance, lifeInsurance, vacationDays);

                // When Hourly Radio Button is Selected do the following
                if (frmInput.HourlyRadioButton.Checked)
                {
                    float hoursWorked = float.Parse(frmInput.HoursWorkedTextbox.Text);
                    float hourlyPay = float.Parse(frmInput.HourlyPayTextbox.Text);
                    employee = new Hourly(firstName, lastName, SSN, hireDate, benefits, maskedSSN, hoursWorked, hourlyPay);
                }
                // When Salary Radio Button is Selected do the following
                else if (frmInput.SalaryRadioButton.Checked)
                {
                    double annualSalary = double.Parse(frmInput.SalaryTextbox.Text);
                    employee = new Salary(firstName, lastName, SSN, hireDate, benefits, maskedSSN, annualSalary);
                }
                // Otherwise, Invalid employee type (Place holder for debugging if any additional types are added)
                else
                {
                    MessageBox.Show("Error. Invalid Employee Type.");
                    return;
                }




                //add new employee object employee list box
                EmployeesListBox.Items.Add(employee);

                //Update Employees.csv file
                WriteEmployeesToFile();
            }
        }
        #endregion
        #region Remove Button Click Event
        private void RemoveButton_Click(object sender, EventArgs e)
        {
            int selectedItem = EmployeesListBox.SelectedIndex;
            if (selectedItem > -1)
            {
                EmployeesListBox.Items.RemoveAt(selectedItem);
                //MessageBox.Show("Removed Item Number: " + selectedItem);
                WriteEmployeesToFile();
            }
            else if (EmployeesListBox.Items.Count == 0)
                MessageBox.Show("There are no employees to remove...", "Error");
            else
                MessageBox.Show("Please select an employee to remove...", "Error");

        }
        #endregion
        #region Print PayChecks Button Click Event
        private void PrintPaychecksButton_Click(object sender, EventArgs e)
        {
            //Create New Printer Form
            PrinterInputForm printerInput = new PrinterInputForm();

            using (printerInput)
            {
                DialogResult result = printerInput.ShowDialog();
                if (printerInput.PrintSelectedRadioButton.Checked)
                {
                    int itemNumber = EmployeesListBox.SelectedIndex;
                    //If no employee is Display Message Box
                    if (itemNumber < 0)
                    {
                        MessageBox.Show("Error. Please Select an Employee from the Employee List Box.");
                        return ;
                    }
                    Employee selectedEmployee = (Employee)EmployeesListBox.Items[itemNumber];
                    MessageBox.Show(selectedEmployee.ToString() + ", Pay for current period: "
                        + selectedEmployee.CalculatePay().ToString("C"), "Bi-Weekly Pay: ");
                }
                else if (printerInput.PrintAllRadioButton.Checked)
                {
                    string payChecks = "";
                    foreach (Employee employee in EmployeesListBox.Items)
                    {
                        payChecks += employee.ToString() + ", Pay for current period: " + employee.CalculatePay().ToString("C") + "\n";
                    }

                    MessageBox.Show(payChecks, "Bi-Weekly Pay:");
                }
                
            }
        }


        
        #endregion
        #region Employee List Box Selected Item Double Clicked Event
        //edit selected employee in the listbox
        private void EmployeesListBox_DoubleClick(object sender, EventArgs e)
        {
            InputForm frmUpdate = new InputForm();

            using (frmUpdate)
            {
                frmUpdate.Text = "Employee Update Form"; // change title bar to display 'Employee Update Form'
                frmUpdate.SubmitButton.Text = "Update"; //change submit button to display 'Update'

                int itemNumber = EmployeesListBox.SelectedIndex; // assign the index of the selected employee to itemNumber

                //If no employee is selected close form
                if (itemNumber < 0)
                {
                    MessageBox.Show("Error. Invalid Employee.");
                    return;
                }
                //Create new Employee Object named selectedEmployee
                Employee selectedEmployee = (Employee)EmployeesListBox.Items[itemNumber];

                frmUpdate.FirstNameTextbox.Text = selectedEmployee.FirstName;
                frmUpdate.LastNameTextbox.Text = selectedEmployee.LastName;
                frmUpdate.SSNTextbox.Text = selectedEmployee.SSN;
                frmUpdate.HireDateTextbox.Text = selectedEmployee.HireDate.ToShortDateString();
                frmUpdate.HealthInsuranceTextbox.Text = selectedEmployee.EmployeeBenefits.HealthInsurance;
                frmUpdate.LifeInsuranceTextbox.Text = selectedEmployee.EmployeeBenefits.LifeInsurance.ToString("C");
                frmUpdate.VacationDaysTextbox.Text = selectedEmployee.EmployeeBenefits.VacationDays.ToString();

                //If Selected Employee is of Type Hourly
                if (selectedEmployee is Hourly)
                {
                    frmUpdate.HourlyRadioButton.Checked = true;
                    Hourly hourlyEmployee = (Hourly)selectedEmployee;
                    frmUpdate.HourlyPayTextbox.Text = hourlyEmployee.HourlyPay.ToString("C");
                    frmUpdate.HoursWorkedTextbox.Text = hourlyEmployee.HoursWorked.ToString("N2");
                }
                // If Selected Employee is of Type Salary
                else if (selectedEmployee is Salary)
                {
                    frmUpdate.SalaryRadioButton.Checked = true;
                    Salary salaryEmployee = (Salary)selectedEmployee;
                    frmUpdate.SalaryTextbox.Text = salaryEmployee.AnnualSalary.ToString("C");
                }


                DialogResult result = frmUpdate.ShowDialog();

                if (result == DialogResult.Cancel) { return; }

                EmployeesListBox.Items.RemoveAt(itemNumber); // remove current selected employee from listbox

                //Pull updated data from update form
                string firstName = frmUpdate.FirstNameTextbox.Text;
                string lastName = frmUpdate.LastNameTextbox.Text;
                string SSN = frmUpdate.SSNTextbox.Text;
                string maskedSSN = MaskSSN(SSN);
                string date = frmUpdate.HireDateTextbox.Text;
                DateTime hireDate = DateTime.Parse(date);
                string healthInsurance = frmUpdate.HealthInsuranceTextbox.Text;
                double lifeInsurance = Double.Parse(frmUpdate.LifeInsuranceTextbox.Text.Substring(1));
                int vacationDays = Int32.Parse(frmUpdate.VacationDaysTextbox.Text);

                //Create new Benefits object
                Benefits benefits = new Benefits(healthInsurance, lifeInsurance, vacationDays);

                //If Selected Employee is of Type Hourly and Hourly Radio Button is Checked
                if (selectedEmployee is Hourly && frmUpdate.HourlyRadioButton.Checked)
                {
                    float hourlyPay;
                    char[] charArray = frmUpdate.HourlyPayTextbox.Text.ToCharArray();
                    if (charArray[0].ToString() == "$")
                    {
                        hourlyPay = float.Parse(frmUpdate.HourlyPayTextbox.Text.Substring(1));
                    }
                    else
                    {
                        hourlyPay = float.Parse(frmUpdate.HourlyPayTextbox.Text);
                    }
                    float hoursWorked = float.Parse(frmUpdate.HoursWorkedTextbox.Text);
                    selectedEmployee = new Hourly(firstName, lastName, SSN, hireDate, benefits, maskedSSN, hourlyPay, hoursWorked);
                }
                // If Selected Employee is of Type Salary and Salary Radio Button is Checked
                else if (selectedEmployee is Salary && frmUpdate.SalaryRadioButton.Checked)
                {
                    double annualSalary;
                    char[] charArray = frmUpdate.SalaryTextbox.Text.ToCharArray();
                    if (charArray[0].ToString() == "$")
                    {
                        annualSalary = float.Parse(frmUpdate.SalaryTextbox.Text.Substring(1));
                    }
                    else
                    {
                        annualSalary = float.Parse(frmUpdate.SalaryTextbox.Text);
                    }
                    selectedEmployee = new Salary(firstName, lastName, SSN, hireDate, benefits, maskedSSN, annualSalary);
                }
                // If User Decides to Change the Employee Type from Hourly to Salary
                else if (selectedEmployee is Hourly  && frmUpdate.SalaryRadioButton.Checked)
                {
                    double annualSalary;
                    char[] charArray = frmUpdate.SalaryTextbox.Text.ToCharArray();
                    if (charArray[0].ToString() == "$")
                    {
                        annualSalary = float.Parse(frmUpdate.SalaryTextbox.Text.Substring(1));
                    }
                    else
                    {
                        annualSalary = float.Parse(frmUpdate.SalaryTextbox.Text);
                    }
                    selectedEmployee = new Salary(firstName, lastName, SSN, hireDate, benefits, maskedSSN, annualSalary);
                }
                // If User Decides to Change the Employee Type from Salary to Hourly
                else if (selectedEmployee is Salary && frmUpdate.HourlyRadioButton.Checked)
                {
                    float hourlyPay;
                    char[] charArray = frmUpdate.HourlyPayTextbox.Text.ToCharArray();
                    if (charArray[0].ToString() == "$")
                    {
                        hourlyPay = float.Parse(frmUpdate.HourlyPayTextbox.Text.Substring(1));
                    }
                    else
                    {
                        hourlyPay = float.Parse(frmUpdate.HourlyPayTextbox.Text);
                    }
                    float hoursWorked = float.Parse(frmUpdate.HoursWorkedTextbox.Text);
                    selectedEmployee = new Hourly(firstName, lastName, SSN, hireDate, benefits, maskedSSN, hourlyPay, hoursWorked);
                }

                //add new employee object employee list box
                EmployeesListBox.Items.Add(selectedEmployee);

                //Update Employees.csv file
                WriteEmployeesToFile();


            }
        }
        #endregion
        #endregion
        #region Methods
        #region WriteEmployeesToFile() Method
        private void WriteEmployeesToFile()

        {
            //Convert the Listbox items into a generic list
            List<Employee> employeeList = new List<Employee>();
            foreach (Employee employee in EmployeesListBox.Items)
            {
                employeeList.Add(employee);
                //MessageBox.Show(employee.ToString());
            }
                //Open a pipe to the file, and create a translator
                FileStream fs = new FileStream(FILENAME, FileMode.Create);
                BinaryFormatter formatter = new BinaryFormatter();

                //Write the Generic List to the File
                formatter.Serialize(fs, employeeList);

                //Close the Pipe
                fs.Close();

                //Confirm Employee has been added to file
                MessageBox.Show("Employee saved to file.");
         
        }
        #endregion
        #region ReadEmployeesFromFile() Method
        private void ReadEmployeesFromFile()
        {
            //Clear Employees List Box
            EmployeesListBox.Items.Clear();

            //Check if File Exists
            if (File.Exists(FILENAME) && new FileInfo(FILENAME).Length > 0)
            {
                //Create a Pipe from File and Create a Binary Translator
                FileStream fs = new FileStream(FILENAME, FileMode.Open);
                BinaryFormatter formatter = new BinaryFormatter();

                //Read all Employee Objects from File
                List<Employee> List = (List<Employee>)formatter.Deserialize(fs);

                //Close Pope from File
                fs.Close();

                //Add each Employee Object to Employee Listbox
                foreach (Employee employee in List) { EmployeesListBox.Items.Add(employee); }
            }
        }
        #endregion
        #region MaskedSSN() Method
        public string MaskSSN(string ssn)
        {
            string temp = ssn.Substring(7);
            string mask = "XXX-XX-";
            string maskedSSN = mask + temp;
            return maskedSSN;
        }
        #endregion
        #endregion
    }
}

