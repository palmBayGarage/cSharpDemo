﻿namespace Glover_CourseProject_part2
{
    partial class PrinterInputForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PrintAllRadioButton = new System.Windows.Forms.RadioButton();
            this.PrintSelectedRadioButton = new System.Windows.Forms.RadioButton();
            this.OkButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PrintAllRadioButton
            // 
            this.PrintAllRadioButton.AutoSize = true;
            this.PrintAllRadioButton.Location = new System.Drawing.Point(30, 40);
            this.PrintAllRadioButton.Name = "PrintAllRadioButton";
            this.PrintAllRadioButton.Size = new System.Drawing.Size(330, 43);
            this.PrintAllRadioButton.TabIndex = 1;
            this.PrintAllRadioButton.TabStop = true;
            this.PrintAllRadioButton.Text = "Print All Paychecks";
            this.PrintAllRadioButton.UseVisualStyleBackColor = true;
            // 
            // PrintSelectedRadioButton
            // 
            this.PrintSelectedRadioButton.AutoSize = true;
            this.PrintSelectedRadioButton.Location = new System.Drawing.Point(30, 98);
            this.PrintSelectedRadioButton.Name = "PrintSelectedRadioButton";
            this.PrintSelectedRadioButton.Size = new System.Drawing.Size(424, 43);
            this.PrintSelectedRadioButton.TabIndex = 2;
            this.PrintSelectedRadioButton.TabStop = true;
            this.PrintSelectedRadioButton.Text = "Print Selected Paychecks";
            this.PrintSelectedRadioButton.UseVisualStyleBackColor = true;
            // 
            // OkButton
            // 
            this.OkButton.Location = new System.Drawing.Point(118, 177);
            this.OkButton.Name = "OkButton";
            this.OkButton.Size = new System.Drawing.Size(248, 60);
            this.OkButton.TabIndex = 3;
            this.OkButton.Text = "OK";
            this.OkButton.UseVisualStyleBackColor = true;
            this.OkButton.Click += new System.EventHandler(this.OkButton_Click);
            // 
            // PrinterInputForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 38F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 277);
            this.Controls.Add(this.OkButton);
            this.Controls.Add(this.PrintSelectedRadioButton);
            this.Controls.Add(this.PrintAllRadioButton);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.Name = "PrinterInputForm";
            this.Text = "Print Paychecks";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button OkButton;
        public System.Windows.Forms.RadioButton PrintAllRadioButton;
        public System.Windows.Forms.RadioButton PrintSelectedRadioButton;
    }
}