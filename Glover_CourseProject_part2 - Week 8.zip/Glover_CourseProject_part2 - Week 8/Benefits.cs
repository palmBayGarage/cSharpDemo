﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Glover_CourseProject_part2
{
    [Serializable]
    internal class Benefits
    {
        #region Attributes
        //Attributes

        private string healthInsurance;
        private double lifeInsurance;
        private int vacationDays;

        #endregion
        #region Properties
        //Properties
        public string HealthInsurance
        {
            get { return healthInsurance; }
            set { healthInsurance = value; }
        }
        public double LifeInsurance
        {
            get { return lifeInsurance; }
            set
            {
                if (value > 0 && value <= 10000000)
                {
                    lifeInsurance = value;
                }
                else
                {
                    lifeInsurance = 0.0;
                }
            }
        }
        public int VacationDays
        {
            get { return vacationDays; }
            set
            {
                if (value > 0 && value <= 80)
                    vacationDays = value;
                else
                    vacationDays = 0;            
            }
        }


        #endregion
        #region Constructors
        //Constructors
        public Benefits()
        {
            healthInsurance = "unknown";
            lifeInsurance = 0.0;
            vacationDays = 0;
        }
        public Benefits(string healthInsurance, double lifeInsurance, int vacationDays)
        {
            HealthInsurance = healthInsurance;
            LifeInsurance = lifeInsurance;
            VacationDays = vacationDays;
        }

        #endregion
        #region Behaviors
        //Behaviors
        public override string ToString()
        {
            return "Health Insurance: " + healthInsurance + "Life Insurance: " + lifeInsurance.ToString()
                + "Vacation Days: " + vacationDays.ToString();
        }
        #endregion
    }
}
