﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Glover_CourseProject_part2
{
    public partial class InputForm : Form
    {
        public InputForm()
        {
            InitializeComponent();
        }
        #region Events
        #region Click Events
        #region Click X Events
        Color selectedColor = Color.LightCyan;
        Color unselectedColor = Color.White;
        Color errorColor = Color.Coral;
        #region First Name Textbox X Click Event
        bool textInFirstNameTextbox = false;
        private void FirstNameTextbox_TextChanged(object sender, EventArgs e)
        {
            FirstNameXLabel.Visible = true;
            FirstNameXLabel.BackColor = selectedColor;
            FirstNameTextbox.BackColor = selectedColor;
            if(FirstNameTextbox.Text != "") textInFirstNameTextbox = true;
            else
            {
                FirstNameXLabel.Visible = false;
                FirstNameXLabel.BackColor = unselectedColor;
                FirstNameTextbox.BackColor = unselectedColor;
            }
        }
        private void FirstNameXLabel_Click(object sender, EventArgs e)
        {
            FirstNameTextbox.Text = "";
            textInFirstNameTextbox = false;
            FirstNameXLabel.Visible = false;
            FirstNameXLabel.BackColor = unselectedColor;
            FirstNameTextbox.BackColor = unselectedColor;
            
        }
        private void FirstNameTextbox_Enter(object sender, EventArgs e)
        {
            if (textInFirstNameTextbox)
            {
                FirstNameXLabel.Visible = true;
                FirstNameXLabel.BackColor = selectedColor;
                FirstNameTextbox.BackColor = selectedColor;
            }
        }
        private void FirstNameTextbox_Leave(object sender, EventArgs e)
        {
            FirstNameXLabel.Visible = false;
            FirstNameXLabel.BackColor = unselectedColor;
            FirstNameTextbox.BackColor = unselectedColor;
        }
        #endregion
        #region Last Name Textbox X Click Event
        bool textInLastNameTextbox = false;
        private void LastNameTextbox_TextChanged(object sender, EventArgs e)
        {
            LastNameTextbox.BackColor = selectedColor;
            LastNameXLabel.BackColor = selectedColor;
            LastNameXLabel.Visible = true;
            if(LastNameTextbox.Text != "") textInLastNameTextbox = true;
            else
            {
                LastNameTextbox.BackColor = unselectedColor;
                LastNameXLabel.Visible = false;
                LastNameXLabel.BackColor = unselectedColor;
            }
        }
        private void LastNameXLabel_Click(object sender, EventArgs e)
        {
            LastNameTextbox.Text = "";
            LastNameTextbox.BackColor = unselectedColor;
            LastNameXLabel.Visible = false;
            LastNameXLabel.BackColor = unselectedColor;
            textInLastNameTextbox = false;
        }
        private void LastNameTextbox_Enter(object sender, EventArgs e)
        {
            if(textInLastNameTextbox == true)
            {
                LastNameTextbox.BackColor = selectedColor;
                LastNameXLabel.BackColor = selectedColor;
                LastNameXLabel.Visible = true;
            }
        }
        private void LastNameTextbox_Leave(object sender, EventArgs e)
        {
            LastNameTextbox.BackColor = unselectedColor;
            LastNameXLabel.Visible = false;
            LastNameXLabel.BackColor = unselectedColor;
        }
        #endregion
        #region SSN Textbox X Click Event
        bool textInSSNTextbox = false;
        bool ssnIsCorrectFormat = true;
        private void SSNTextbox_TextChanged(object sender, EventArgs e)
        {
            
            if (SSNTextbox.Text == "")
            {
                textInSSNTextbox = false;
                SSNTextbox.BackColor = unselectedColor;
                SSNXLabel.BackColor = unselectedColor;
                SSNXLabel.Visible = false;
                SSNExampleLabel.Visible = true;
                SSNExampleLabel.BackColor = unselectedColor;
            }
            else
            {
                SSNExampleLabel.Visible = false;
                SSNTextbox.BackColor = selectedColor;
                SSNXLabel.BackColor = selectedColor;
                SSNXLabel.Visible = true;
                textInSSNTextbox = true;
            }
        }
        private void SSNXLabel_Click(object sender, EventArgs e)
        {
            SSNTextbox.Text = "";
            SSNTextbox.BackColor = unselectedColor;
            SSNXLabel.BackColor = unselectedColor;
            SSNExampleLabel.BackColor = unselectedColor;
            SSNXLabel.Visible = false;
            textInSSNTextbox = false;
            ssnIsCorrectFormat = true;
        }
        private void SSNTextbox_Enter(object sender, EventArgs e)
        {
            if(textInSSNTextbox && ssnIsCorrectFormat || SSNTextbox.Text == "")
            {
                if (SSNTextbox.Text == "") { SSNExampleLabel.Visible = true; }
                else { SSNExampleLabel.Visible = false; }
                SSNTextbox.BackColor = unselectedColor;
                SSNXLabel.BackColor = unselectedColor;
                SSNExampleLabel.BackColor = unselectedColor;
                if (SSNTextbox.Text == "") { SSNXLabel.Visible = false; }
                else { SSNXLabel.Visible = true; }
            }
            else
            {
                SSNTextbox.Text = "";
                SSNExampleLabel.Visible = true;
                SSNExampleLabel.BackColor = errorColor;
                SSNTextbox.BackColor = errorColor;
                SSNXLabel.BackColor = errorColor;
                ssnIsCorrectFormat = true;
            }
        }

        private void SSNTextbox_Leave(object sender, EventArgs e)
        {
            if (SSNTextbox.Text == "" || CheckSSNFormat(SSNTextbox.Text))
            {
                SSNTextbox.BackColor = unselectedColor;
                SSNXLabel.BackColor = unselectedColor;
                SSNXLabel.Visible = false;
                SSNExampleLabel.Visible = false;
                ssnIsCorrectFormat = true;
            }
            else
            {
                SSNTextbox.BackColor = errorColor;
                SSNExampleLabel.BackColor = errorColor;
                SSNXLabel.BackColor = errorColor;
                MessageBox.Show("Please format Social Security Number as shown: XXX-XX-XXXX, Where X, " +
                    "only numbers, no letters, or special characters", "Format Error");
                ssnIsCorrectFormat = false;
            }

        }
        #endregion
        #region Hire Date Textbox X Click Event
        bool textIsInHireDateTextbox = false;
        bool hireDateIsCorrect = true;
        private void HireDateTextbox_TextChanged(object sender, EventArgs e)
        {
            if (HireDateTextbox.Text == "")
            {
                textIsInHireDateTextbox = false;
                HireDateTextbox.BackColor = unselectedColor;
                HireDateXLabel.BackColor = unselectedColor;
                HireDateXLabel.Visible = false;
                HireDateExampleLabel.Visible = true;
                HireDateExampleLabel.BackColor = unselectedColor;
            }
            else
            {
                textIsInHireDateTextbox = true;
                HireDateTextbox.BackColor = selectedColor;
                HireDateXLabel.BackColor = selectedColor;
                HireDateXLabel.Visible = true;
                HireDateExampleLabel.Visible = false;
                HireDateExampleLabel.BackColor = selectedColor;
                hireDateIsCorrect = true;
            }
        }
        private void HireDateXLabel_Click(object sender, EventArgs e)
        {
                HireDateTextbox.Text = "";
                HireDateTextbox.BackColor = unselectedColor;
                HireDateXLabel.BackColor = unselectedColor;
                HireDateExampleLabel.BackColor = unselectedColor;
                HireDateXLabel.Visible = false;
                textIsInHireDateTextbox = false;
                hireDateIsCorrect = true;
        }
        private void HireDateTextbox_Enter(object sender, EventArgs e)
        {
            if (textIsInHireDateTextbox && hireDateIsCorrect || HireDateTextbox.Text == "")
            {
                if (HireDateTextbox.Text == "") { HireDateExampleLabel.Visible = true; }
                else { HireDateExampleLabel.Visible = false; }
                HireDateTextbox.BackColor = unselectedColor;
                HireDateXLabel.BackColor = unselectedColor;
                if(HireDateTextbox.Text == "") { HireDateXLabel.Visible = false; }
                else { HireDateXLabel.Visible = true; }
                
            }
            else 
            {
                HireDateTextbox.Text = "";
                HireDateExampleLabel.Visible = true;
                HireDateExampleLabel.BackColor = errorColor;
                HireDateTextbox.BackColor = errorColor;
                HireDateXLabel.BackColor = errorColor;
                hireDateIsCorrect = true;
            }
        }

        private void HireDateTextbox_Leave(object sender, EventArgs e)
        {
            if (HireDateTextbox.Text != "")
            {
                if (CheckDateFormat(HireDateTextbox.Text))
                {
                    HireDateTextbox.BackColor = unselectedColor;
                    HireDateXLabel.BackColor = unselectedColor;
                    HireDateXLabel.Visible = false;
                    HireDateExampleLabel.Visible = false;
                    hireDateIsCorrect = true;
                }
                else
                {
                    HireDateTextbox.BackColor = errorColor;
                    HireDateExampleLabel.BackColor = errorColor;
                    HireDateXLabel.BackColor = errorColor;
                    MessageBox.Show("Please format date as shown: MM/DD/YYYY.", "Format Error");
                    hireDateIsCorrect = false;
                }

            }
            else
            {
                HireDateTextbox.BackColor = unselectedColor;
                HireDateXLabel.BackColor = unselectedColor;
                HireDateXLabel.Visible = false;
                HireDateExampleLabel.Visible = false;
                hireDateIsCorrect = true;
            }

        }
        #endregion
        #region Hourly Pay Textbox X Click Event
        bool textIsInHourlyPayTextbox = false;
        private void HourlyPayTextbox_TextChanged(object sender, EventArgs e)
        {
            HourlyPayTextbox.BackColor = selectedColor;
            PayXLabel.BackColor = selectedColor;
            PayXLabel.Visible = true;
            if (HourlyPayTextbox.Text != "") textIsInHourlyPayTextbox = true;
            else
            {
                HourlyPayTextbox.BackColor = unselectedColor;
                PayXLabel.BackColor = unselectedColor;
                PayXLabel.Visible = false;
            }
        }
        private void PayXLabel_Click(object sender, EventArgs e)
        {
            HourlyPayTextbox.Text = "";
            HourlyPayTextbox.BackColor = unselectedColor;
            PayXLabel.BackColor = unselectedColor;
            PayXLabel.Visible = false;
            textIsInHourlyPayTextbox = false;
        }
        private void HourlyPayTextbox_Enter(object sender, EventArgs e)
        {
            if (textIsInHourlyPayTextbox)
            {
                HourlyPayTextbox.BackColor = selectedColor;
                PayXLabel.BackColor = selectedColor;
                PayXLabel.Visible = true;
            }
        }

        private void HourlyPayTextbox_Leave(object sender, EventArgs e)
        {
            HourlyPayTextbox.BackColor = unselectedColor;
            PayXLabel.BackColor = unselectedColor;
            PayXLabel.Visible = false;
        }
        #endregion
        #region Hours Worked Textbox X Click Event
        bool textIsInHoursWorkedTextbox = false;
        private void HoursWorkedTextbox_TextChanged(object sender, EventArgs e)
        {
            HoursWorkedTextbox.BackColor = selectedColor;
            WorkedXLabel.BackColor = selectedColor;
            WorkedXLabel.Visible = true;
            if (HoursWorkedTextbox.Text != "") textIsInHoursWorkedTextbox = true;
            else
            {
                HoursWorkedTextbox.BackColor = unselectedColor;
                WorkedXLabel.BackColor = unselectedColor;
                WorkedXLabel.Visible = false;
            }
        }
        private void WorkedXLabel_Click(object sender, EventArgs e)
        {
            HoursWorkedTextbox.Text = "";
            HoursWorkedTextbox.BackColor = unselectedColor;
            WorkedXLabel.BackColor = unselectedColor;
            WorkedXLabel.Visible = false;
            textIsInHoursWorkedTextbox = false;
        }
        private void HoursWorkedTextbox_Enter(object sender, EventArgs e)
        {
            if (textIsInHoursWorkedTextbox)
            {
                HoursWorkedTextbox.BackColor = selectedColor;
                WorkedXLabel.BackColor = selectedColor;
                WorkedXLabel.Visible = true;
            }
        }

        private void HoursWorkedTextbox_Leave(object sender, EventArgs e)
        {
            HoursWorkedTextbox.BackColor = unselectedColor;
            WorkedXLabel.BackColor = unselectedColor;
            WorkedXLabel.Visible = false;
        }
        #endregion
        #region Annual Salary Textbox X Click Event
        bool textIsInSalaryTextbox = false;
        private void SalaryTextbox_TextChanged(object sender, EventArgs e)
        {
            SalaryTextbox.BackColor = selectedColor;
            SalaryXlabel.BackColor = selectedColor;
            SalaryXlabel.Visible = true;
            if (SalaryTextbox.Text != "") textIsInSalaryTextbox = true;
            else
            {
                SalaryTextbox.BackColor = unselectedColor;
                SalaryXlabel.BackColor = unselectedColor;
                SalaryXlabel.Visible = false;
            }
        }

            private void SalaryXlabel_Click(object sender, EventArgs e)
        {
            SalaryTextbox.Text = "";
            SalaryTextbox.BackColor = unselectedColor;
            SalaryXlabel.BackColor = unselectedColor;
            SalaryXlabel.Visible = false;
            textIsInSalaryTextbox = false;
        }
        private void SalaryTextbox_Enter(object sender, EventArgs e)
        {
            if(textIsInSalaryTextbox == true)
            {
                SalaryTextbox.BackColor = selectedColor;
                SalaryXlabel.BackColor = selectedColor;
                SalaryXlabel.Visible = true;
            }
        }

        private void SalaryTextbox_Leave(object sender, EventArgs e)
        {
            SalaryTextbox.BackColor = unselectedColor;
            SalaryXlabel.BackColor = unselectedColor;
            SalaryXlabel.Visible = false;
        }
        #endregion
        #region Health Insurance Textbox X Click Event
        bool textIsInHealthInsuranceTextbox = false;
        private void HealthInsuranceTextbox_TextChanged(object sender, EventArgs e)
        {
            HealthInsuranceTextbox.BackColor = selectedColor;
            HealthXLabel.BackColor = selectedColor;
            HealthXLabel.Visible = true;
            if(HealthInsuranceTextbox.Text != "") textIsInSalaryTextbox = true;
            else
            {
                HealthInsuranceTextbox.BackColor = unselectedColor;
                HealthXLabel.BackColor = unselectedColor;
                HealthXLabel.Visible = false;
            }
        }
        private void HealthXLabel_Click(object sender, EventArgs e)
        {
            HealthInsuranceTextbox.Text = "";
            HealthInsuranceTextbox.BackColor = unselectedColor;
            HealthXLabel.BackColor = unselectedColor;
            HealthXLabel.Visible = false;
            textIsInSalaryTextbox = false;
        }
        private void HealthInsuranceTextbox_Enter(object sender, EventArgs e)
        {
            if (textIsInHealthInsuranceTextbox)
            {
                HealthInsuranceTextbox.BackColor = selectedColor;
                HealthXLabel.BackColor = selectedColor;
                HealthXLabel.Visible = true;
            }
        }

        private void HealthInsuranceTextbox_Leave(object sender, EventArgs e)
        {
            HealthInsuranceTextbox.BackColor = unselectedColor;
            HealthXLabel.BackColor = unselectedColor;
            HealthXLabel.Visible = false;
        }
        #endregion
        #region Life Insurance X Click Event
        bool textIsInLifeInsuranceTextbox = false;
        private void LifeInsuranceTextbox_TextChanged(object sender, EventArgs e)
        {
            LifeInsuranceTextbox.BackColor = selectedColor;
            LifeXLabel.BackColor = selectedColor;
            LifeXLabel.Visible = true;
            if(LifeInsuranceTextbox.Text != "") textIsInLifeInsuranceTextbox = true;
            else
            {
                LifeInsuranceTextbox.BackColor = unselectedColor;
                LifeXLabel.BackColor = unselectedColor;
                LifeXLabel.Visible = false;
            }
        }
        private void LifeXLabel_Click(object sender, EventArgs e)
        {
            LifeInsuranceTextbox.Text = "";
            LifeInsuranceTextbox.BackColor = unselectedColor;
            LifeXLabel.BackColor = unselectedColor;
            LifeXLabel.Visible = false;
            textIsInLifeInsuranceTextbox = false;
        }
        private void LifeInsuranceTextbox_Enter(object sender, EventArgs e)
        {
            if (textIsInLifeInsuranceTextbox)
            {
                LifeInsuranceTextbox.BackColor = selectedColor;
                LifeXLabel.BackColor = selectedColor;
                LifeXLabel.Visible = true;
            }
        }

        private void LifeInsuranceTextbox_Leave(object sender, EventArgs e)
        {
            LifeInsuranceTextbox.BackColor = unselectedColor;
            LifeXLabel.BackColor = unselectedColor;
            LifeXLabel.Visible = false;
        }

        #endregion
        #region Vacation Days X Click Event
        bool textIsInVacationDaysTextbox = false;
        private void VacationDaysTextbox_TextChanged(object sender, EventArgs e)
        {
            if(VacationDaysTextbox.Text != "")
            {
                VacationDaysTextbox.BackColor = selectedColor;
                VacationXLabel.BackColor = selectedColor;
                VacationXLabel.Visible = true;
                textIsInVacationDaysTextbox = true;
            }
            else
            {
                VacationDaysTextbox.BackColor = unselectedColor;
                VacationXLabel.BackColor = unselectedColor;
                VacationXLabel.Visible = false;
            }
        }
        private void VacationXLabel_Click(object sender, EventArgs e)
        {
            VacationDaysTextbox.Text = "";
            VacationDaysTextbox.BackColor = unselectedColor;
            VacationXLabel.BackColor = unselectedColor;
            VacationXLabel.Visible = false;
            textIsInVacationDaysTextbox = false;
        }
        private void VacationDaysTextbox_Enter(object sender, EventArgs e)
        {
            if (textIsInVacationDaysTextbox)
            {
                VacationDaysTextbox.BackColor = selectedColor;
                VacationXLabel.BackColor = selectedColor;
                VacationXLabel.Visible = true;
            }

        }

        private void VacationDaysTextbox_Leave(object sender, EventArgs e)
        {
            VacationDaysTextbox.BackColor = unselectedColor;
            VacationXLabel.BackColor = unselectedColor;
            VacationXLabel.Visible = false;
        }
        #endregion
        #region Submit Button Click Event
        private void SubmitButton_Click(object sender, EventArgs e)
        {
            string stringErrorMessage = "";
            bool boolFlag = true;
            if (HourlyRadioButton.Checked && (HourlyPayTextbox.Text == "" || HoursWorkedTextbox.Text == ""))
            {
                stringErrorMessage = "Please correct the following errors:";
                stringErrorMessage += string.IsNullOrEmpty(HourlyPayTextbox.Text)
               ? "\n ~ \' Hourly Pay \' cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(HoursWorkedTextbox.Text)
                    ? "\n ~ \' Hours Worked \' cannot be blank" : string.Empty;
                boolFlag = false;
            }
            else if (SalaryRadioButton.Checked && string.IsNullOrEmpty(SalaryTextbox.Text))
            {
                stringErrorMessage = "Please correct the following errors:";
                stringErrorMessage += string.IsNullOrEmpty(SalaryTextbox.Text)
                   ? "\n ~ \' Annual Salary \' cannot be blank" : string.Empty;
                boolFlag = false;

            }
            if (ValidInput(stringErrorMessage, boolFlag))
            {
                if (hireDateIsCorrect && ssnIsCorrectFormat)
                {
                    this.DialogResult = DialogResult.OK;
                }
                else
                {
                    MessageBox.Show("Please correct formatting errors.");
                }
                
            }

        }
        #endregion
        #region Cancel Button Click Event
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
        #endregion
        #endregion
        #region Radio Button Click Events
        #region Salary Radio Button Click Event
        private void SalaryRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            SalaryLabel.Visible = true;
            SalaryTextbox.Visible = true;
            SalaryTextbox.TabIndex = 6;
            HoursWorkedLabel.Visible = false;
            HoursWorkedTextbox.Visible = false;
            HoursWorkedTextbox.Text = "";
            HourlyPayTextbox.Text = "";
            HourlyPayTextbox.Visible = false;
            HourlyPayTextbox.TabIndex = 11;
        }
        #endregion
        #region Hourly Radio Button Click Event
        private void HourlyRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            SalaryLabel.Visible = false;
            SalaryTextbox.Visible = false;
            SalaryTextbox.Text = "";
            SalaryTextbox.TabIndex = 11;
            HoursWorkedLabel.Visible = true;
            HoursWorkedTextbox.Visible = true;
            HourlyPayLabel.Visible = true;
            HourlyPayTextbox.Visible = true;
            HourlyPayTextbox.TabIndex = 6;
        }
        #endregion
        #endregion
        #endregion
        #region Keydown Events
        Control ctrl;
        #region First Name Keydown Event
        private void FirstNameTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);
        }
        #endregion
        #region Last Name Keydown Event
        private void LastNameTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);
        }
        #endregion
        #region SSN Keydown Event
        private void SSNTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);

        }
        #endregion
        #region Hire Date Keydown Event
        private void HireDateTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);
        }
        #endregion
        #region Hourly Pay Keydown Event
        private void HourlyPayTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);
        }
        #endregion
        #region Hours Worked Keydown Event
        private void HoursWorkedTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);
        }
        #endregion
        #region Annual Salary Keydown Event
        private void SalaryTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);
        }
        #endregion
        #region Health Insurance Keydown Event
        private void HealthInsuranceTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);
        }
        #endregion
        #region Life Insurance Keydown Event
        private void LifeInsuranceTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);
        }
        #endregion
        #region Vacation Days Keydown Event
        private void VacationDaysTextbox_KeyDown(object sender, KeyEventArgs e)
        {
            EnterAsTab(sender, e);
        }
        #endregion
        #endregion
        #endregion
        #region Methods
        #region ValidInput() Method
        private bool ValidInput(string stringErrorMessage, bool boolFlag)
        {
            StringBuilder sb = new StringBuilder(string.Empty);
            if(boolFlag != false) { boolFlag = true; }
            if(stringErrorMessage == "") { stringErrorMessage = "Please correct the following errors: "; }

            if (string.IsNullOrEmpty(FirstNameTextbox.Text) || string.IsNullOrEmpty(LastNameTextbox.Text)
                    || string.IsNullOrEmpty(SSNTextbox.Text) || string.IsNullOrEmpty(HireDateTextbox.Text)
                    || string.IsNullOrEmpty(HealthInsuranceTextbox.Text) || string.IsNullOrEmpty(LifeInsuranceTextbox.Text)
                    || string.IsNullOrEmpty(VacationDaysTextbox.Text))
            {
                stringErrorMessage += string.IsNullOrEmpty(FirstNameTextbox.Text) 
                   ? "\n ~ \'First Name\' cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(LastNameTextbox.Text) 
                    ? "\n ~ \'Last Name\' cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(SSNTextbox.Text) 
                    ? "\n ~ \'SSN\' cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(HireDateTextbox.Text)
                    ? "\n ~ \'Hire Date\' cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(HealthInsuranceTextbox.Text)
                    ? "\n ~ \'Health Insurance \' cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(LifeInsuranceTextbox.Text)
                    ? "\n ~ \' Life Insurance \' cannot be blank" : string.Empty;
                stringErrorMessage += string.IsNullOrEmpty(VacationDaysTextbox.Text)
                    ? "\n ~ \' Vacation Days \' cannot be blank" : string.Empty;

                boolFlag = false;
            }
         

            if (!boolFlag)
            {
                MessageBox.Show(stringErrorMessage, "Missing Input", MessageBoxButtons.OK);
            }
            return boolFlag;
        }
        #endregion

        #region EnterAsTab()
        public void EnterAsTab(Object sender, KeyEventArgs e)
        {
            ctrl = (Control)sender;
            if (ctrl is TextBox)
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Down)
                {
                    this.SelectNextControl(ctrl, true, true, true, true);
                    e.Handled = e.SuppressKeyPress = true;
                }
                else if (e.KeyCode == Keys.Up)
                {
                    this.SelectNextControl(ctrl, false, true, true, true);
                    e.Handled = e.SuppressKeyPress = true;
                }
                else
                {
                    return;
                }
            }
          
        }
        #endregion
        #region CheckDateFormat()
        public bool CheckDateFormat(string date)
        {
            string[] format = { "MM/dd/yyyy", "M/d/yyyy", "MM/d/yyyy", "M/dd/yyyy" };
            DateTime dateTime;
            if (DateTime.TryParseExact(date, format, new CultureInfo("en-US"),
                              DateTimeStyles.None, out dateTime))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion
        #region CheckSSNFormat()
        public bool CheckSSNFormat(string ssn)
        {
            string SSNPattern = @"^\d{3}\-?\d{2}\-?\d{4}$";
            Regex regex = new Regex(SSNPattern);
            bool Matching = regex.IsMatch(ssn);
            return Matching;
        }
        #endregion
        #endregion
    }
}
