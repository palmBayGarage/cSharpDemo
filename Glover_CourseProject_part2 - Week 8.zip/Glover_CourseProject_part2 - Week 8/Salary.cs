﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Glover_CourseProject_part2
{
    [Serializable]
    internal class Salary : Employee
    {
        #region Attributes
        //Attributes
        private double annualSalary;
        #endregion
        #region Properties
        //Properties
        public double AnnualSalary
        {
            get { return annualSalary; }
            set
            {
                if (value > 0.0 && value < 1000000.00) { annualSalary = value; }
                else value = 0.0;
            }
        }
        #endregion
        #region Constructors
        //Constructors
        public Salary() : base()
        {
            annualSalary = 0.0;
        }

        public Salary(string firstName, string lastName, string ssn,
            DateTime hireDate, Benefits benefits, string maskedSSN, double annualSalary) 
            : base(firstName, lastName, ssn, hireDate, benefits, maskedSSN)
        {
            AnnualSalary = annualSalary;
        }



        #endregion
        #region Behaviors
        //Behaviors
        #region ToString() Behavior
        public override string ToString()
        {
            return base.ToString() + ", Annual Salary: " + annualSalary.ToString("C");
        }
        #endregion
        #region CalculatePay() Behavior
        public override double CalculatePay()
        {
            return annualSalary / 26.0;
        }
        #endregion
        #endregion
    }
}
