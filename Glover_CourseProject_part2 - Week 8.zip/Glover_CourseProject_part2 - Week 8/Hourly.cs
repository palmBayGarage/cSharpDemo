﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Glover_CourseProject_part2
{
    [Serializable]
    internal class Hourly : Employee
    {
        #region Attributes
        //Attributes
        private float hoursWorked;
        private float hourlyPay;
        #endregion
        #region Properties
        //Properties
        public float HoursWorked
        {
            get { return hoursWorked; }
            set 
            {
                if (value > 0.0f && value <= 200.0f)
                    hoursWorked = value;
                else hoursWorked = 0.0f;
            }
        }
        public float HourlyPay
        {
            get { return hourlyPay; }
            set
            {
                if (value > 0.0f && value <= 1000.00f)
                    hourlyPay = value;
                else hourlyPay = 0.0f;
            }
        }
     

        #endregion
        #region Constuctors
        //Constructors
        public Hourly() : base()
        {
            hoursWorked = 0.0f;
        }
        public Hourly(string firstName, string lastName, string ssn, DateTime hireDate, 
            Benefits benefits, string maskedSSN, float hourlyPay, float hoursWorked)
            : base(firstName, lastName, ssn, hireDate, benefits, maskedSSN)
        {
            HourlyPay = hourlyPay;
            HoursWorked = hoursWorked;
        }

        #endregion
        #region Behaviors
        //Behaviors
        #region ToString() Behavior
        public override string ToString()
        {
            return base.ToString() + ", Hourly Pay: " + hourlyPay.ToString("C") 
                + "/hr, Hours Worked: " + hoursWorked.ToString();
        }
        #endregion
        #region CalculatePay() Behavior
        public override double CalculatePay()
        {
            double pay = 0.0f;
            if (hoursWorked > 40.0f)
            {
                double basePay = hourlyPay * 40.0f;
                double overtime = (hoursWorked - 40.0f) * hourlyPay * 1.5f;
                pay = basePay + overtime;
            }
            else { pay = hourlyPay * hoursWorked; }
            return pay;
        }
        #endregion
        #endregion

    }
}
